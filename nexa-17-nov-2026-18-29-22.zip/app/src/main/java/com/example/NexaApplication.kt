package com.example

import android.app.Application
import com.example.core.media.MediaHelper
import com.example.core.media.VoicePlayerManager
import com.example.core.media.VoiceRecorderManager
import com.example.data.local.NexaDatabase
import com.example.data.preferences.SessionPreferences
import com.example.data.repository.*
import com.example.domain.repository.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(application: Application) {
    private val database: NexaDatabase = NexaDatabase.getInstance(application)
    private val dao = database.nexaDao()
    private val sessionPreferences = SessionPreferences(application)

    val mediaHelper = MediaHelper(application)
    val voiceRecorderManager = VoiceRecorderManager(application, mediaHelper)
    val voicePlayerManager = VoicePlayerManager(application)

    val authRepository: AuthRepository = AuthRepositoryImpl(dao, sessionPreferences)
    val socialRepository: SocialRepository = SocialRepositoryImpl(dao)
    val messagingRepository: MessagingRepository = MessagingRepositoryImpl(dao)
    val videoRepository: VideoRepository = VideoRepositoryImpl(dao)
    val settingsRepository: SettingsRepository = SettingsRepositoryImpl(sessionPreferences, dao)

    init {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            database.ensureSeeded(application)
            socialRepository.purgeExpiredStories()
        }
    }
}

class NexaApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
