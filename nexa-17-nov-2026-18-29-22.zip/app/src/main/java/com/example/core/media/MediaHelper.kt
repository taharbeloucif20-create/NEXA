package com.example.core.media

import android.content.ContentValues
import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.net.toUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.UUID

class MediaHelper(private val context: Context) {

    private val imagesDir = File(context.filesDir, "nexa_images").apply { mkdirs() }
    private val videosDir = File(context.filesDir, "nexa_videos").apply { mkdirs() }
    private val voiceDir = File(context.filesDir, "nexa_voice").apply { mkdirs() }

    suspend fun persistPickedImage(sourceUri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(imagesDir, "img_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            } ?: error("Cannot open selected image")
            file.toUri().toString()
        }
    }

    suspend fun persistPickedVideo(sourceUri: Uri): Result<Pair<String, Long>> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(videosDir, "vid_${UUID.randomUUID()}.mp4")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            } ?: error("Cannot open selected video")
            val durationSec = readVideoDurationSeconds(file)
            file.toUri().toString() to durationSec
        }
    }

    private fun readVideoDurationSeconds(file: File): Long {
        return try {
            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(file.absolutePath)
            val durationMs = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            (durationMs / 1000L).coerceAtLeast(1L)
        } catch (_: Exception) {
            10L
        }
    }

    suspend fun saveVideoToGallery(videoUriString: String, titleSlug: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val safeName = "NEXA_${titleSlug.replace(Regex("[^a-zA-Z0-9_]"), "_").take(24)}_${System.currentTimeMillis()}.mp4"
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, safeName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NEXA")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            val targetUri = resolver.insert(collection, values) ?: error("Unable to create MediaStore entry")
            openVideoStream(videoUriString).use { input ->
                resolver.openOutputStream(targetUri)?.use { output ->
                    input.copyTo(output)
                } ?: error("Unable to write video stream")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(targetUri, values, null, null)
            }
            safeName
        }
    }

    private fun openVideoStream(uriString: String): InputStream {
        val uri = uriString.toUri()
        return when (uri.scheme) {
            "android.resource" -> context.contentResolver.openInputStream(uri)
                ?: error("Cannot open raw resource")
            "file" -> FileInputStream(File(requireNotNull(uri.path)))
            else -> context.contentResolver.openInputStream(uri)
                ?: error("Cannot open video URI")
        }
    }

    fun createVoiceOutputFile(): File = File(voiceDir, "voice_${UUID.randomUUID()}.m4a")
}

class VoiceRecorderManager(private val context: Context, private val mediaHelper: MediaHelper) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var startTimeMs: Long = 0L

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    fun startRecording(): Result<Unit> = runCatching {
        stopSilently()
        val file = mediaHelper.createVoiceOutputFile()
        currentFile = file
        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        rec.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(96_000)
            setAudioSamplingRate(44_100)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        recorder = rec
        startTimeMs = System.currentTimeMillis()
        _isRecording.value = true
    }

    fun stopAndSave(): Pair<String, Long>? {
        val file = currentFile ?: return null
        val durationSec = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
        return try {
            recorder?.apply {
                stop()
                release()
            }
            recorder = null
            _isRecording.value = false
            file.toUri().toString() to durationSec
        } catch (_: Exception) {
            stopSilently()
            null
        }
    }

    fun cancelRecording() {
        stopSilently()
        currentFile?.delete()
        currentFile = null
    }

    private fun stopSilently() {
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null
        _isRecording.value = false
    }
}

class VoicePlayerManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private val _playingMessageId = MutableStateFlow<String?>(null)
    val playingMessageId: StateFlow<String?> = _playingMessageId.asStateFlow()

    fun togglePlay(messageId: String, uriString: String) {
        if (_playingMessageId.value == messageId) {
            stop()
            return
        }
        stop()
        try {
            val player = MediaPlayer().apply {
                setDataSource(context, uriString.toUri())
                setOnCompletionListener {
                    _playingMessageId.value = null
                    release()
                    if (mediaPlayer === this) mediaPlayer = null
                }
                prepare()
                start()
            }
            mediaPlayer = player
            _playingMessageId.value = messageId
        } catch (_: Exception) {
            stop()
        }
    }

    fun stop() {
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
        _playingMessageId.value = null
    }
}
