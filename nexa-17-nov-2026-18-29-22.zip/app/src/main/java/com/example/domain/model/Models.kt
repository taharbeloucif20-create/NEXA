package com.example.domain.model

enum class PrivacyScope {
    EVERYONE,
    FRIENDS_ONLY,
    PRIVATE
}

enum class MessageType {
    TEXT,
    IMAGE,
    VOICE,
    CALL_VOICE,
    CALL_VIDEO
}

enum class MessageStatus {
    SENT,
    DELIVERED,
    READ
}

enum class VideoKind {
    REEL,
    LONG
}

enum class FriendshipState {
    SELF,
    NONE,
    REQUEST_SENT,
    REQUEST_RECEIVED,
    FRIENDS,
    BLOCKED
}

enum class ReportReason {
    SPAM,
    HARASSMENT,
    INAPPROPRIATE,
    IMPERSONATION
}

data class UserProfile(
    val id: String,
    val username: String,
    val bio: String,
    val avatarUri: String?,
    val profileVisibility: PrivacyScope = PrivacyScope.EVERYONE,
    val allowFriendRequests: Boolean = true,
    val allowMessagesFrom: PrivacyScope = PrivacyScope.EVERYONE,
    val showReadReceipts: Boolean = true,
    val allowVideoDownloadsDefault: Boolean = true,
    val createdAt: Long
)

data class FriendRequestItem(
    val id: Long,
    val fromUser: UserProfile,
    val toUser: UserProfile,
    val createdAt: Long
)

data class PostItem(
    val id: String,
    val author: UserProfile,
    val content: String,
    val imageUri: String?,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val likedByMe: Boolean,
    val createdAt: Long
)

data class CommentItem(
    val id: String,
    val targetId: String,
    val author: UserProfile,
    val content: String,
    val createdAt: Long
)

data class StoryItem(
    val id: String,
    val author: UserProfile,
    val caption: String,
    val imageUri: String?,
    val createdAt: Long,
    val expiresAt: Long
)

data class StoryGroup(
    val author: UserProfile,
    val stories: List<StoryItem>
)

data class ChatMessage(
    val id: String,
    val senderId: String,
    val receiverId: String,
    val type: MessageType,
    val textContent: String,
    val mediaUri: String?,
    val durationSec: Long,
    val status: MessageStatus,
    val createdAt: Long
)

data class ConversationSummary(
    val peer: UserProfile,
    val lastMessage: ChatMessage,
    val unreadCount: Int
)

data class VideoItem(
    val id: String,
    val author: UserProfile,
    val title: String,
    val kind: VideoKind,
    val videoUri: String,
    val durationSec: Long,
    val allowDownload: Boolean,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val likedByMe: Boolean,
    val createdAt: Long
)

data class NotificationItem(
    val id: String,
    val actorName: String,
    val actorId: String,
    val messageAr: String,
    val messageEn: String,
    val read: Boolean,
    val createdAt: Long
)

data class SearchResults(
    val users: List<UserProfile> = emptyList(),
    val posts: List<PostItem> = emptyList(),
    val videos: List<VideoItem> = emptyList()
)
