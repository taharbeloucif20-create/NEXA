package com.example.domain.repository

import com.example.core.i18n.AppLanguage
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    val currentUserId: Flow<String?>
    fun observeCurrentUser(): Flow<UserProfile?>
    suspend fun register(username: String, password: String, bio: String, avatarUri: String?): Result<UserProfile>
    suspend fun login(uniqueId: String, password: String): Result<UserProfile>
    suspend fun signOut()
    suspend fun updateProfile(username: String, bio: String, avatarUri: String?): Result<Unit>
}

interface SocialRepository {
    fun observeFeedPosts(viewerId: String): Flow<List<PostItem>>
    fun observeUserPosts(viewerId: String, targetUserId: String): Flow<List<PostItem>>
    fun observeActiveStories(viewerId: String): Flow<List<StoryGroup>>
    fun observePostComments(postId: String): Flow<List<CommentItem>>
    fun observeFriends(userId: String): Flow<List<UserProfile>>
    fun observeIncomingRequests(userId: String): Flow<List<FriendRequestItem>>
    fun observeBlockedUsers(userId: String): Flow<List<UserProfile>>
    fun observeNotifications(userId: String): Flow<List<NotificationItem>>
    fun observeUser(userId: String): Flow<UserProfile?>
    suspend fun getFriendshipState(viewerId: String, targetId: String): FriendshipState
    suspend fun createPost(authorId: String, content: String, imageUri: String?): Result<Unit>
    suspend fun deletePost(userId: String, postId: String): Result<Unit>
    suspend fun togglePostLike(userId: String, postId: String): Result<Unit>
    suspend fun addPostComment(userId: String, postId: String, content: String): Result<Unit>
    suspend fun incrementPostShare(postId: String): Result<Unit>
    suspend fun createStory(authorId: String, caption: String, imageUri: String?): Result<Unit>
    suspend fun purgeExpiredStories()
    suspend fun sendFriendRequest(fromId: String, toId: String): Result<Unit>
    suspend fun acceptFriendRequest(requestId: Long): Result<Unit>
    suspend fun declineFriendRequest(requestId: Long): Result<Unit>
    suspend fun removeFriend(userId: String, friendId: String): Result<Unit>
    suspend fun searchAll(viewerId: String, query: String): SearchResults
    suspend fun blockUser(blockerId: String, blockedId: String): Result<Unit>
    suspend fun unblockUser(blockerId: String, blockedId: String): Result<Unit>
    suspend fun reportUserOrContent(reporterId: String, targetUserId: String, targetContentId: String?, reason: ReportReason, details: String): Result<Unit>
    suspend fun markNotificationRead(notificationId: String)
    suspend fun markAllNotificationsRead(userId: String)
}

interface MessagingRepository {
    fun observeConversations(userId: String): Flow<List<ConversationSummary>>
    fun observeMessages(userId: String, peerId: String): Flow<List<ChatMessage>>
    suspend fun sendTextMessage(senderId: String, receiverId: String, text: String): Result<Unit>
    suspend fun sendImageMessage(senderId: String, receiverId: String, imageUri: String): Result<Unit>
    suspend fun sendVoiceMessage(senderId: String, receiverId: String, voiceUri: String, durationSec: Long): Result<Unit>
    suspend fun logCallRecord(senderId: String, receiverId: String, isVideo: Boolean, durationSec: Long): Result<Unit>
    suspend fun markConversationRead(viewerId: String, peerId: String)
    suspend fun canMessage(senderId: String, receiverId: String): Boolean
}

interface VideoRepository {
    fun observeVideos(viewerId: String, kind: VideoKind): Flow<List<VideoItem>>
    fun observeVideoComments(videoId: String): Flow<List<CommentItem>>
    suspend fun uploadVideo(
        authorId: String,
        title: String,
        kind: VideoKind,
        videoUri: String,
        durationSec: Long,
        allowDownload: Boolean
    ): Result<Unit>
    suspend fun toggleVideoLike(userId: String, videoId: String): Result<Unit>
    suspend fun addVideoComment(userId: String, videoId: String, content: String): Result<Unit>
    suspend fun incrementVideoShare(videoId: String): Result<Unit>
}

interface SettingsRepository {
    val isDarkTheme: Flow<Boolean>
    val language: Flow<AppLanguage>
    suspend fun setDarkTheme(enabled: Boolean)
    suspend fun setLanguage(language: AppLanguage)
    suspend fun updatePrivacySettings(
        userId: String,
        profileVisibility: PrivacyScope,
        allowFriendRequests: Boolean,
        allowMessagesFrom: PrivacyScope,
        showReadReceipts: Boolean,
        allowVideoDownloadsDefault: Boolean
    ): Result<Unit>
}
