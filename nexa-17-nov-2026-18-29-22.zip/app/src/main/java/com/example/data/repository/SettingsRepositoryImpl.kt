package com.example.data.repository

import com.example.core.i18n.AppLanguage
import com.example.data.local.NexaDao
import com.example.data.preferences.SessionPreferences
import com.example.domain.model.PrivacyScope
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow

class SettingsRepositoryImpl(
    private val prefs: SessionPreferences,
    private val dao: NexaDao
) : SettingsRepository {

    override val isDarkTheme: Flow<Boolean> = prefs.isDarkTheme
    override val language: Flow<AppLanguage> = prefs.language

    override suspend fun setDarkTheme(enabled: Boolean) {
        prefs.setDarkTheme(enabled)
    }

    override suspend fun setLanguage(language: AppLanguage) {
        prefs.setLanguage(language)
    }

    override suspend fun updatePrivacySettings(
        userId: String,
        profileVisibility: PrivacyScope,
        allowFriendRequests: Boolean,
        allowMessagesFrom: PrivacyScope,
        showReadReceipts: Boolean,
        allowVideoDownloadsDefault: Boolean
    ): Result<Unit> = runCatching {
        val user = dao.getUserById(userId) ?: error("User not found")
        dao.updateUser(
            user.copy(
                profileVisibility = profileVisibility.name,
                allowFriendRequests = allowFriendRequests,
                allowMessagesFrom = allowMessagesFrom.name,
                showReadReceipts = showReadReceipts,
                allowVideoDownloadsDefault = allowVideoDownloadsDefault
            )
        )
    }
}
