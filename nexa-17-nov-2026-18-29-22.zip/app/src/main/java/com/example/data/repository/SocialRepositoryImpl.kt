package com.example.data.repository

import com.example.data.local.*
import com.example.domain.model.*
import com.example.domain.repository.SocialRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.util.UUID

class SocialRepositoryImpl(private val dao: NexaDao) : SocialRepository {

    override fun observeFeedPosts(viewerId: String): Flow<List<PostItem>> {
        val baseFlow = combine(
            dao.observeAllPosts(),
            dao.observeAllUsers(),
            dao.observeAllPostLikes(),
            dao.observeCommentsByType("POST"),
            dao.observeFriendIds(viewerId)
        ) { posts, users, likes, comments, friendIds ->
            val userMap = users.associateBy { it.id }
            val friendSet = friendIds.toSet()
            posts.mapNotNull { post ->
                val author = userMap[post.authorId]?.toDomain() ?: return@mapNotNull null
                val visible = when {
                    author.id == viewerId -> true
                    author.profileVisibility == PrivacyScope.EVERYONE -> true
                    author.profileVisibility == PrivacyScope.FRIENDS_ONLY -> author.id in friendSet
                    else -> false
                }
                if (!visible) return@mapNotNull null
                val postLikes = likes.filter { it.postId == post.id }
                val commentCount = comments.count { it.targetId == post.id }
                PostItem(
                    id = post.id,
                    author = author,
                    content = post.content,
                    imageUri = post.imageUri,
                    likesCount = postLikes.size,
                    commentsCount = commentCount,
                    sharesCount = post.sharesCount,
                    likedByMe = postLikes.any { it.userId == viewerId },
                    createdAt = post.createdAt
                )
            }
        }
        return combine(baseFlow, dao.observeAnyBlockParticipantIds(viewerId)) { posts, blocked ->
            val blockedSet = blocked.toSet()
            posts.filter { it.author.id !in blockedSet }
        }
    }

    override fun observeUserPosts(viewerId: String, targetUserId: String): Flow<List<PostItem>> =
        observeFeedPosts(viewerId).map { list -> list.filter { it.author.id == targetUserId } }

    override fun observeActiveStories(viewerId: String): Flow<List<StoryGroup>> {
        val now = System.currentTimeMillis()
        return combine(
            dao.observeActiveStories(now),
            dao.observeAllUsers(),
            dao.observeAnyBlockParticipantIds(viewerId),
            dao.observeFriendIds(viewerId)
        ) { stories, users, blocked, friends ->
            val userMap = users.associateBy { it.id }
            val blockedSet = blocked.toSet()
            val friendSet = friends.toSet()
            val validStories = stories
                .filter { it.expiresAt > System.currentTimeMillis() }
                .filter { it.authorId !in blockedSet }
                .mapNotNull { story ->
                    val author = userMap[story.authorId]?.toDomain() ?: return@mapNotNull null
                    val visible = when {
                        author.id == viewerId -> true
                        author.profileVisibility == PrivacyScope.EVERYONE -> true
                        author.profileVisibility == PrivacyScope.FRIENDS_ONLY -> author.id in friendSet
                        else -> false
                    }
                    if (!visible) return@mapNotNull null
                    StoryItem(
                        id = story.id,
                        author = author,
                        caption = story.caption,
                        imageUri = story.imageUri,
                        createdAt = story.createdAt,
                        expiresAt = story.expiresAt
                    )
                }
            validStories
                .groupBy { it.author.id }
                .values
                .map { group ->
                    StoryGroup(
                        author = group.first().author,
                        stories = group.sortedBy { it.createdAt }
                    )
                }
                .sortedByDescending { it.author.id == viewerId }
        }
    }

    override fun observePostComments(postId: String): Flow<List<CommentItem>> =
        combine(
            dao.observeCommentsForTarget(postId, "POST"),
            dao.observeAllUsers()
        ) { comments, users ->
            val userMap = users.associateBy { it.id }
            comments.mapNotNull { c ->
                val author = userMap[c.authorId]?.toDomain() ?: return@mapNotNull null
                CommentItem(
                    id = c.id,
                    targetId = c.targetId,
                    author = author,
                    content = c.content,
                    createdAt = c.createdAt
                )
            }
        }

    override fun observeFriends(userId: String): Flow<List<UserProfile>> =
        combine(
            dao.observeFriendIds(userId),
            dao.observeAllUsers(),
            dao.observeAnyBlockParticipantIds(userId)
        ) { friendIds, users, blocked ->
            val blockedSet = blocked.toSet()
            val userMap = users.associateBy { it.id }
            friendIds
                .filter { it !in blockedSet }
                .mapNotNull { userMap[it]?.toDomain() }
        }

    override fun observeIncomingRequests(userId: String): Flow<List<FriendRequestItem>> =
        combine(
            dao.observeIncomingRequests(userId),
            dao.observeAllUsers(),
            dao.observeAnyBlockParticipantIds(userId)
        ) { requests, users, blocked ->
            val blockedSet = blocked.toSet()
            val userMap = users.associateBy { it.id }
            requests.mapNotNull { req ->
                if (req.fromUserId in blockedSet) return@mapNotNull null
                val from = userMap[req.fromUserId]?.toDomain() ?: return@mapNotNull null
                val to = userMap[req.toUserId]?.toDomain() ?: return@mapNotNull null
                FriendRequestItem(req.id, from, to, req.createdAt)
            }
        }

    override fun observeBlockedUsers(userId: String): Flow<List<UserProfile>> =
        combine(dao.observeBlockedIds(userId), dao.observeAllUsers()) { blockedIds, users ->
            val userMap = users.associateBy { it.id }
            blockedIds.mapNotNull { userMap[it]?.toDomain() }
        }

    override fun observeNotifications(userId: String): Flow<List<NotificationItem>> =
        dao.observeNotifications(userId).map { list -> list.map { it.toDomain() } }

    override fun observeUser(userId: String): Flow<UserProfile?> =
        dao.observeUserById(userId).map { it?.toDomain() }

    override suspend fun getFriendshipState(viewerId: String, targetId: String): FriendshipState {
        if (viewerId == targetId) return FriendshipState.SELF
        if (dao.isBlockedBetween(viewerId, targetId) > 0) return FriendshipState.BLOCKED
        if (dao.isFriends(viewerId, targetId) > 0) return FriendshipState.FRIENDS
        if (dao.getPendingRequest(viewerId, targetId) != null) return FriendshipState.REQUEST_SENT
        if (dao.getPendingRequest(targetId, viewerId) != null) return FriendshipState.REQUEST_RECEIVED
        return FriendshipState.NONE
    }

    override suspend fun createPost(authorId: String, content: String, imageUri: String?): Result<Unit> = runCatching {
        val clean = content.trim()
        require(clean.isNotBlank() || !imageUri.isNullOrBlank()) { "Post cannot be empty" }
        dao.insertPost(
            PostEntity(
                id = UUID.randomUUID().toString(),
                authorId = authorId,
                content = clean,
                imageUri = imageUri,
                sharesCount = 0,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun deletePost(userId: String, postId: String): Result<Unit> = runCatching {
        dao.deletePost(postId, userId)
    }

    override suspend fun togglePostLike(userId: String, postId: String): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        if (dao.hasLikedPost(postId, userId) > 0) {
            dao.deletePostLike(postId, userId)
        } else {
            dao.insertPostLike(PostLikeEntity(postId, userId, now))
            val post = dao.getPostById(postId)
            val actor = dao.getUserById(userId)
            if (post != null && actor != null && post.authorId != userId) {
                dao.insertNotification(
                    NotificationEntity(
                        id = UUID.randomUUID().toString(),
                        userId = post.authorId,
                        actorId = userId,
                        actorName = actor.username,
                        messageAr = "أعجب ${actor.username} بمنشورك",
                        messageEn = "${actor.username} liked your post",
                        read = false,
                        createdAt = now
                    )
                )
            }
        }
    }

    override suspend fun addPostComment(userId: String, postId: String, content: String): Result<Unit> = runCatching {
        val clean = content.trim()
        require(clean.isNotBlank()) { "Comment cannot be empty" }
        val now = System.currentTimeMillis()
        dao.insertComment(
            CommentEntity(
                id = UUID.randomUUID().toString(),
                targetId = postId,
                targetType = "POST",
                authorId = userId,
                content = clean,
                createdAt = now
            )
        )
        val post = dao.getPostById(postId)
        val actor = dao.getUserById(userId)
        if (post != null && actor != null && post.authorId != userId) {
            dao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    userId = post.authorId,
                    actorId = userId,
                    actorName = actor.username,
                    messageAr = "علّق ${actor.username} على منشورك: ${clean.take(40)}",
                    messageEn = "${actor.username} commented on your post: ${clean.take(40)}",
                    read = false,
                    createdAt = now
                )
            )
        }
    }

    override suspend fun incrementPostShare(postId: String): Result<Unit> = runCatching {
        dao.incrementPostShare(postId)
    }

    override suspend fun createStory(authorId: String, caption: String, imageUri: String?): Result<Unit> = runCatching {
        val clean = caption.trim()
        require(clean.isNotBlank() || !imageUri.isNullOrBlank()) { "Story cannot be empty" }
        val now = System.currentTimeMillis()
        dao.insertStory(
            StoryEntity(
                id = UUID.randomUUID().toString(),
                authorId = authorId,
                caption = clean,
                imageUri = imageUri,
                createdAt = now,
                expiresAt = now + 24L * 60L * 60L * 1000L
            )
        )
    }

    override suspend fun purgeExpiredStories() {
        dao.purgeExpiredStories(System.currentTimeMillis())
    }

    override suspend fun sendFriendRequest(fromId: String, toId: String): Result<Unit> = runCatching {
        val normalizedToId = toId.trim().uppercase()
        require(normalizedToId != fromId) { "SELF" }
        val target = dao.getUserById(normalizedToId) ?: error("NOT_FOUND")
        require(dao.isBlockedBetween(fromId, normalizedToId) == 0) { "BLOCKED" }
        require(target.allowFriendRequests) { "REQUESTS_DISABLED" }
        if (dao.isFriends(fromId, normalizedToId) > 0) error("ALREADY_FRIENDS")
        if (dao.getPendingRequest(fromId, normalizedToId) != null) error("ALREADY_SENT")

        val reverse = dao.getPendingRequest(normalizedToId, fromId)
        if (reverse != null) {
            acceptFriendRequest(reverse.id).getOrThrow()
            return@runCatching
        }

        val now = System.currentTimeMillis()
        dao.insertFriendRequest(
            FriendRequestEntity(
                fromUserId = fromId,
                toUserId = normalizedToId,
                status = "PENDING",
                createdAt = now
            )
        )
        val actor = dao.getUserById(fromId)
        if (actor != null) {
            dao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    userId = normalizedToId,
                    actorId = fromId,
                    actorName = actor.username,
                    messageAr = "أرسل لك ${actor.username} طلب صداقة",
                    messageEn = "${actor.username} sent you a friend request",
                    read = false,
                    createdAt = now
                )
            )
        }
    }

    override suspend fun acceptFriendRequest(requestId: Long): Result<Unit> = runCatching {
        val req = dao.getFriendRequestById(requestId) ?: error("Request not found")
        dao.updateFriendRequestStatus(requestId, "ACCEPTED")
        val now = System.currentTimeMillis()
        dao.insertFriendship(FriendshipEntity(req.fromUserId, req.toUserId, now))
        dao.insertFriendship(FriendshipEntity(req.toUserId, req.fromUserId, now))
        val accepter = dao.getUserById(req.toUserId)
        if (accepter != null) {
            dao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    userId = req.fromUserId,
                    actorId = req.toUserId,
                    actorName = accepter.username,
                    messageAr = "قبل ${accepter.username} طلب صداقتك",
                    messageEn = "${accepter.username} accepted your friend request",
                    read = false,
                    createdAt = now
                )
            )
        }
    }

    override suspend fun declineFriendRequest(requestId: Long): Result<Unit> = runCatching {
        dao.updateFriendRequestStatus(requestId, "DECLINED")
    }

    override suspend fun removeFriend(userId: String, friendId: String): Result<Unit> = runCatching {
        dao.deleteFriendshipPair(userId, friendId)
    }

    override suspend fun searchAll(viewerId: String, query: String): SearchResults {
        val q = query.trim()
        if (q.isBlank()) return SearchResults()
        val friends = dao.getFriendIds(viewerId).toSet()
        val users = dao.searchUsers(q)
            .filter { it.id != viewerId && dao.isBlockedBetween(viewerId, it.id) == 0 }
            .map { it.toDomain() }
        val userMap = users.associateBy { it.id }

        val posts = dao.searchPosts(q).mapNotNull { post ->
            if (dao.isBlockedBetween(viewerId, post.authorId) > 0) return@mapNotNull null
            val author = userMap[post.authorId] ?: dao.getUserById(post.authorId)?.toDomain() ?: return@mapNotNull null
            val visible = author.id == viewerId ||
                author.profileVisibility == PrivacyScope.EVERYONE ||
                (author.profileVisibility == PrivacyScope.FRIENDS_ONLY && author.id in friends)
            if (!visible) return@mapNotNull null
            PostItem(
                id = post.id,
                author = author,
                content = post.content,
                imageUri = post.imageUri,
                likesCount = 0,
                commentsCount = 0,
                sharesCount = post.sharesCount,
                likedByMe = false,
                createdAt = post.createdAt
            )
        }

        val videos = dao.searchVideos(q).mapNotNull { video ->
            if (dao.isBlockedBetween(viewerId, video.authorId) > 0) return@mapNotNull null
            val author = userMap[video.authorId] ?: dao.getUserById(video.authorId)?.toDomain() ?: return@mapNotNull null
            VideoItem(
                id = video.id,
                author = author,
                title = video.title,
                kind = enumValues<VideoKind>().firstOrNull { it.name == video.kind } ?: VideoKind.REEL,
                videoUri = video.videoUri,
                durationSec = video.durationSec,
                allowDownload = video.allowDownload,
                likesCount = 0,
                commentsCount = 0,
                sharesCount = video.sharesCount,
                likedByMe = false,
                createdAt = video.createdAt
            )
        }

        return SearchResults(users = users, posts = posts, videos = videos)
    }

    override suspend fun blockUser(blockerId: String, blockedId: String): Result<Unit> = runCatching {
        require(blockerId != blockedId)
        dao.insertBlock(BlockEntity(blockerId, blockedId, System.currentTimeMillis()))
        dao.deleteFriendshipPair(blockerId, blockedId)
    }

    override suspend fun unblockUser(blockerId: String, blockedId: String): Result<Unit> = runCatching {
        dao.deleteBlock(blockerId, blockedId)
    }

    override suspend fun reportUserOrContent(
        reporterId: String,
        targetUserId: String,
        targetContentId: String?,
        reason: ReportReason,
        details: String
    ): Result<Unit> = runCatching {
        dao.insertReport(
            ReportEntity(
                id = UUID.randomUUID().toString(),
                reporterId = reporterId,
                targetUserId = targetUserId,
                targetContentId = targetContentId,
                reason = reason.name,
                details = details.trim(),
                createdAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun markNotificationRead(notificationId: String) {
        dao.markNotificationRead(notificationId)
    }

    override suspend fun markAllNotificationsRead(userId: String) {
        dao.markAllNotificationsRead(userId)
    }
}
