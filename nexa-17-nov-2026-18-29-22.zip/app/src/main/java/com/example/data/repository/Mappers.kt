package com.example.data.repository

import com.example.data.local.*
import com.example.domain.model.*

internal fun UserEntity.toDomain(): UserProfile = UserProfile(
    id = id,
    username = username,
    bio = bio,
    avatarUri = avatarUri,
    profileVisibility = enumValues<PrivacyScope>().firstOrNull { it.name == profileVisibility } ?: PrivacyScope.EVERYONE,
    allowFriendRequests = allowFriendRequests,
    allowMessagesFrom = enumValues<PrivacyScope>().firstOrNull { it.name == allowMessagesFrom } ?: PrivacyScope.EVERYONE,
    showReadReceipts = showReadReceipts,
    allowVideoDownloadsDefault = allowVideoDownloadsDefault,
    createdAt = createdAt
)

internal fun MessageEntity.toDomain(): ChatMessage = ChatMessage(
    id = id,
    senderId = senderId,
    receiverId = receiverId,
    type = enumValues<MessageType>().firstOrNull { it.name == type } ?: MessageType.TEXT,
    textContent = textContent,
    mediaUri = mediaUri,
    durationSec = durationSec,
    status = enumValues<MessageStatus>().firstOrNull { it.name == status } ?: MessageStatus.SENT,
    createdAt = createdAt
)

internal fun NotificationEntity.toDomain(): NotificationItem = NotificationItem(
    id = id,
    actorName = actorName,
    actorId = actorId,
    messageAr = messageAr,
    messageEn = messageEn,
    read = read,
    createdAt = createdAt
)
