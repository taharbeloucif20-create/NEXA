package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.R
import com.example.core.security.PasswordHasher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Database(
    entities = [
        UserEntity::class,
        FriendRequestEntity::class,
        FriendshipEntity::class,
        PostEntity::class,
        PostLikeEntity::class,
        CommentEntity::class,
        StoryEntity::class,
        MessageEntity::class,
        VideoEntity::class,
        VideoLikeEntity::class,
        NotificationEntity::class,
        BlockEntity::class,
        ReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NexaDatabase : RoomDatabase() {
    abstract fun nexaDao(): NexaDao

    suspend fun ensureSeeded(context: Context) = withContext(Dispatchers.IO) {
        val dao = nexaDao()
        if (dao.countAllUsers() > 0) return@withContext

        val now = System.currentTimeMillis()
        val pkg = context.packageName
        val demoHash = PasswordHasher.hashPassword("nexa1234")

        val laila = UserEntity(
            id = "NX-100001",
            username = "ليلى المنصور",
            bio = "مصورة معمارية • أرى العالم بتدرجات الأبيض والأسود.",
            avatarUri = "android.resource://$pkg/${R.drawable.img_story_bw_minimal}",
            passwordHash = demoHash,
            profileVisibility = "EVERYONE",
            allowFriendRequests = true,
            allowMessagesFrom = "EVERYONE",
            showReadReceipts = true,
            allowVideoDownloadsDefault = true,
            createdAt = now - 86_400_000L * 3
        )
        val omar = UserEntity(
            id = "NX-100002",
            username = "عمر الخالدي",
            bio = "صانع أفلام قصيرة ومحتوى بصري بسيط.",
            avatarUri = "android.resource://$pkg/${R.drawable.img_nexa_hero}",
            passwordHash = demoHash,
            profileVisibility = "EVERYONE",
            allowFriendRequests = true,
            allowMessagesFrom = "EVERYONE",
            showReadReceipts = true,
            allowVideoDownloadsDefault = true,
            createdAt = now - 86_400_000L * 2
        )
        val noor = UserEntity(
            id = "NX-100003",
            username = "نور الهدى",
            bio = "مصممة واجهات وتجارب رقمية في NEXA.",
            avatarUri = "android.resource://$pkg/${R.drawable.img_post_bw_arch}",
            passwordHash = demoHash,
            profileVisibility = "EVERYONE",
            allowFriendRequests = true,
            allowMessagesFrom = "EVERYONE",
            showReadReceipts = true,
            allowVideoDownloadsDefault = false,
            createdAt = now - 86_400_000L
        )
        dao.insertUsersIgnore(listOf(laila, omar, noor))

        dao.insertFriendshipsIgnore(
            listOf(
                FriendshipEntity("NX-100001", "NX-100002", now - 3600_000L),
                FriendshipEntity("NX-100002", "NX-100001", now - 3600_000L)
            )
        )

        dao.insertPostsIgnore(
            listOf(
                PostEntity(
                    id = "post_seed_1",
                    authorId = "NX-100001",
                    content = "الضوء والظل هما اللغة الأصدق في الهندسة المعمارية الحديثة. لقطة صباحية من المتحف.",
                    imageUri = "android.resource://$pkg/${R.drawable.img_post_bw_arch}",
                    sharesCount = 14,
                    createdAt = now - 7_200_000L
                ),
                PostEntity(
                    id = "post_seed_2",
                    authorId = "NX-100002",
                    content = "مساء هادئ في الاستوديو أثناء مونتاج الفيديو الطويل الجديد بالأبيض والأسود. شاركوني رأيكم في قسم الفيديو.",
                    imageUri = null,
                    sharesCount = 5,
                    createdAt = now - 3_600_000L
                )
            )
        )

        dao.insertStoriesIgnore(
            listOf(
                StoryEntity(
                    id = "story_seed_1",
                    authorId = "NX-100001",
                    caption = "ظلال الظهيرة في الرواق الحجري",
                    imageUri = "android.resource://$pkg/${R.drawable.img_story_bw_minimal}",
                    createdAt = now - 1_800_000L,
                    expiresAt = now - 1_800_000L + 86_400_000L
                ),
                StoryEntity(
                    id = "story_seed_2",
                    authorId = "NX-100003",
                    caption = "تصميم جديد قيد الإطلاق على NEXA",
                    imageUri = "android.resource://$pkg/${R.drawable.img_nexa_hero}",
                    createdAt = now - 900_000L,
                    expiresAt = now - 900_000L + 86_400_000L
                )
            )
        )

        dao.insertVideosIgnore(
            listOf(
                VideoEntity(
                    id = "video_reel_seed_1",
                    authorId = "NX-100001",
                    title = "إيقاع الخطوات والضوء • ريلز أحادي اللون",
                    kind = "REEL",
                    videoUri = "android.resource://$pkg/${R.raw.reel_sample_1}",
                    durationSec = 6,
                    allowDownload = true,
                    sharesCount = 19,
                    createdAt = now - 5_400_000L
                ),
                VideoEntity(
                    id = "video_long_seed_1",
                    authorId = "NX-100002",
                    title = "جماليات العمارة الصامتة — فيلم وثائقي قصير",
                    kind = "LONG",
                    videoUri = "android.resource://$pkg/${R.raw.long_video_sample_1}",
                    durationSec = 10,
                    allowDownload = true,
                    sharesCount = 8,
                    createdAt = now - 4_000_000L
                )
            )
        )
    }

    companion object {
        @Volatile
        private var INSTANCE: NexaDatabase? = null

        fun getInstance(context: Context): NexaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NexaDatabase::class.java,
                    "nexa_social.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
