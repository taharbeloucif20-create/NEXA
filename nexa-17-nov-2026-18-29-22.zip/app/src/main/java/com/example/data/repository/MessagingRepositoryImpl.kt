package com.example.data.repository

import com.example.data.local.MessageEntity
import com.example.data.local.NexaDao
import com.example.data.local.NotificationEntity
import com.example.domain.model.*
import com.example.domain.repository.MessagingRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.util.UUID

class MessagingRepositoryImpl(private val dao: NexaDao) : MessagingRepository {

    override fun observeConversations(userId: String): Flow<List<ConversationSummary>> =
        combine(
            dao.observeUserMessages(userId),
            dao.observeAllUsers(),
            dao.observeAnyBlockParticipantIds(userId)
        ) { messages, users, blocked ->
            val blockedSet = blocked.toSet()
            val userMap = users.associateBy { it.id }
            val byPeer = LinkedHashMap<String, MutableList<MessageEntity>>()
            for (msg in messages) {
                val peerId = if (msg.senderId == userId) msg.receiverId else msg.senderId
                if (peerId in blockedSet) continue
                byPeer.getOrPut(peerId) { mutableListOf() }.add(msg)
            }
            byPeer.mapNotNull { (peerId, thread) ->
                val peer = userMap[peerId]?.toDomain() ?: return@mapNotNull null
                val latest = thread.maxByOrNull { it.createdAt } ?: return@mapNotNull null
                val unread = thread.count { it.receiverId == userId && it.status != MessageStatus.READ.name }
                ConversationSummary(peer = peer, lastMessage = latest.toDomain(), unreadCount = unread)
            }.sortedByDescending { it.lastMessage.createdAt }
        }

    override fun observeMessages(userId: String, peerId: String): Flow<List<ChatMessage>> =
        combine(
            dao.observeThreadMessages(userId, peerId),
            dao.observeAnyBlockParticipantIds(userId)
        ) { list, blocked ->
            if (peerId in blocked) emptyList() else list.map { it.toDomain() }
        }

    override suspend fun canMessage(senderId: String, receiverId: String): Boolean {
        if (senderId == receiverId) return false
        if (dao.isBlockedBetween(senderId, receiverId) > 0) return false
        val receiver = dao.getUserById(receiverId)?.toDomain() ?: return false
        return when (receiver.allowMessagesFrom) {
            PrivacyScope.EVERYONE -> true
            PrivacyScope.FRIENDS_ONLY -> dao.isFriends(senderId, receiverId) > 0
            PrivacyScope.PRIVATE -> false
        }
    }

    override suspend fun sendTextMessage(senderId: String, receiverId: String, text: String): Result<Unit> = runCatching {
        val clean = text.trim()
        require(clean.isNotBlank()) { "Message cannot be empty" }
        require(canMessage(senderId, receiverId)) { "Messaging restricted by user privacy or block settings" }
        insertMessageAndNotify(
            senderId = senderId,
            receiverId = receiverId,
            type = MessageType.TEXT,
            textContent = clean,
            mediaUri = null,
            durationSec = 0L
        )
    }

    override suspend fun sendImageMessage(senderId: String, receiverId: String, imageUri: String): Result<Unit> = runCatching {
        require(canMessage(senderId, receiverId)) { "Messaging restricted by user privacy or block settings" }
        insertMessageAndNotify(
            senderId = senderId,
            receiverId = receiverId,
            type = MessageType.IMAGE,
            textContent = "",
            mediaUri = imageUri,
            durationSec = 0L
        )
    }

    override suspend fun sendVoiceMessage(
        senderId: String,
        receiverId: String,
        voiceUri: String,
        durationSec: Long
    ): Result<Unit> = runCatching {
        require(canMessage(senderId, receiverId)) { "Messaging restricted by user privacy or block settings" }
        insertMessageAndNotify(
            senderId = senderId,
            receiverId = receiverId,
            type = MessageType.VOICE,
            textContent = "",
            mediaUri = voiceUri,
            durationSec = durationSec
        )
    }

    override suspend fun logCallRecord(
        senderId: String,
        receiverId: String,
        isVideo: Boolean,
        durationSec: Long
    ): Result<Unit> = runCatching {
        insertMessageAndNotify(
            senderId = senderId,
            receiverId = receiverId,
            type = if (isVideo) MessageType.CALL_VIDEO else MessageType.CALL_VOICE,
            textContent = "",
            mediaUri = null,
            durationSec = durationSec
        )
    }

    override suspend fun markConversationRead(viewerId: String, peerId: String) {
        val viewer = dao.getUserById(viewerId)
        val status = if (viewer?.showReadReceipts == false) MessageStatus.DELIVERED.name else MessageStatus.READ.name
        dao.updateIncomingStatus(senderId = peerId, receiverId = viewerId, status = status)
    }

    private suspend fun insertMessageAndNotify(
        senderId: String,
        receiverId: String,
        type: MessageType,
        textContent: String,
        mediaUri: String?,
        durationSec: Long
    ) {
        val now = System.currentTimeMillis()
        dao.insertMessage(
            MessageEntity(
                id = UUID.randomUUID().toString(),
                senderId = senderId,
                receiverId = receiverId,
                type = type.name,
                textContent = textContent,
                mediaUri = mediaUri,
                durationSec = durationSec,
                status = MessageStatus.DELIVERED.name,
                createdAt = now
            )
        )
        val sender = dao.getUserById(senderId)
        if (sender != null) {
            val previewAr = when (type) {
                MessageType.TEXT -> textContent.take(32)
                MessageType.IMAGE -> "أرسل صورة"
                MessageType.VOICE -> "أرسل رسالة صوتية"
                MessageType.CALL_VOICE -> "مكالمة صوتية"
                MessageType.CALL_VIDEO -> "مكالمة فيديو"
            }
            val previewEn = when (type) {
                MessageType.TEXT -> textContent.take(32)
                MessageType.IMAGE -> "Sent a photo"
                MessageType.VOICE -> "Sent a voice message"
                MessageType.CALL_VOICE -> "Voice call"
                MessageType.CALL_VIDEO -> "Video call"
            }
            dao.insertNotification(
                NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    userId = receiverId,
                    actorId = senderId,
                    actorName = sender.username,
                    messageAr = "${sender.username}: $previewAr",
                    messageEn = "${sender.username}: $previewEn",
                    read = false,
                    createdAt = now
                )
            )
        }
    }
}
