package com.example.data.repository

import com.example.core.security.PasswordHasher
import com.example.data.local.NexaDao
import com.example.data.local.NotificationEntity
import com.example.data.local.UserEntity
import com.example.data.preferences.SessionPreferences
import com.example.domain.model.UserProfile
import com.example.domain.repository.AuthRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import java.util.UUID

class AuthRepositoryImpl(
    private val dao: NexaDao,
    private val prefs: SessionPreferences
) : AuthRepository {

    override val currentUserId: Flow<String?> = prefs.currentUserId

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeCurrentUser(): Flow<UserProfile?> =
        prefs.currentUserId.flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(null)
            else dao.observeUserById(uid).map { it?.toDomain() }
        }

    override suspend fun register(
        username: String,
        password: String,
        bio: String,
        avatarUri: String?
    ): Result<UserProfile> = runCatching {
        val cleanName = username.trim()
        require(cleanName.length >= 2) { "Username must be at least 2 characters" }
        require(password.length >= 6) { "Password must be at least 6 characters" }

        var generatedId: String
        do {
            generatedId = PasswordHasher.generateCandidateNexaId()
        } while (dao.countUserById(generatedId) > 0)

        val now = System.currentTimeMillis()
        val passwordHash = PasswordHasher.hashPassword(password)
        val user = UserEntity(
            id = generatedId,
            username = cleanName,
            bio = bio.trim(),
            avatarUri = avatarUri,
            passwordHash = passwordHash,
            profileVisibility = "EVERYONE",
            allowFriendRequests = true,
            allowMessagesFrom = "EVERYONE",
            showReadReceipts = true,
            allowVideoDownloadsDefault = true,
            createdAt = now
        )
        dao.insertUser(user)
        dao.insertNotification(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                userId = generatedId,
                actorId = "NX-100001",
                actorName = "NEXA",
                messageAr = "مرحباً بك في NEXA! معرّفك الفريد هو $generatedId",
                messageEn = "Welcome to NEXA! Your unique ID is $generatedId",
                read = false,
                createdAt = now
            )
        )
        prefs.setCurrentUserId(generatedId)
        user.toDomain()
    }

    override suspend fun login(uniqueId: String, password: String): Result<UserProfile> = runCatching {
        val normalizedId = uniqueId.trim().uppercase()
        require(normalizedId.isNotBlank()) { "ID is required" }
        require(password.isNotBlank()) { "Password is required" }

        val user = dao.getUserById(normalizedId)
            ?: error("Invalid ID or password")
        if (!PasswordHasher.verifyPassword(password, user.passwordHash)) {
            error("Invalid ID or password")
        }
        prefs.setCurrentUserId(user.id)
        user.toDomain()
    }

    override suspend fun signOut() {
        prefs.setCurrentUserId(null)
    }

    override suspend fun updateProfile(
        username: String,
        bio: String,
        avatarUri: String?
    ): Result<Unit> = runCatching {
        val uid = prefs.currentUserId.first() ?: error("Not authenticated")
        val existing = dao.getUserById(uid) ?: error("User not found")
        val cleanName = username.trim()
        require(cleanName.length >= 2) { "Username must be at least 2 characters" }
        dao.updateUser(
            existing.copy(
                username = cleanName,
                bio = bio.trim(),
                avatarUri = avatarUri ?: existing.avatarUri
            )
        )
    }
}
