package com.example.data.repository

import com.example.data.local.*
import com.example.domain.model.CommentItem
import com.example.domain.model.VideoItem
import com.example.domain.model.VideoKind
import com.example.domain.repository.VideoRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.util.UUID

class VideoRepositoryImpl(private val dao: NexaDao) : VideoRepository {

    override fun observeVideos(viewerId: String, kind: VideoKind): Flow<List<VideoItem>> {
        val base = combine(
            dao.observeVideosByKind(kind.name),
            dao.observeAllUsers(),
            dao.observeAllVideoLikes(),
            dao.observeCommentsByType("VIDEO")
        ) { videos, users, likes, comments ->
            val userMap = users.associateBy { it.id }
            videos.mapNotNull { video ->
                val author = userMap[video.authorId]?.toDomain() ?: return@mapNotNull null
                val videoLikes = likes.filter { it.videoId == video.id }
                val commentCount = comments.count { it.targetId == video.id }
                VideoItem(
                    id = video.id,
                    author = author,
                    title = video.title,
                    kind = kind,
                    videoUri = video.videoUri,
                    durationSec = video.durationSec,
                    allowDownload = video.allowDownload,
                    likesCount = videoLikes.size,
                    commentsCount = commentCount,
                    sharesCount = video.sharesCount,
                    likedByMe = videoLikes.any { it.userId == viewerId },
                    createdAt = video.createdAt
                )
            }
        }
        return combine(base, dao.observeAnyBlockParticipantIds(viewerId)) { list, blocked ->
            val blockedSet = blocked.toSet()
            list.filter { it.author.id !in blockedSet }
        }
    }

    override fun observeVideoComments(videoId: String): Flow<List<CommentItem>> =
        combine(
            dao.observeCommentsForTarget(videoId, "VIDEO"),
            dao.observeAllUsers()
        ) { comments, users ->
            val userMap = users.associateBy { it.id }
            comments.mapNotNull { c ->
                val author = userMap[c.authorId]?.toDomain() ?: return@mapNotNull null
                CommentItem(
                    id = c.id,
                    targetId = c.targetId,
                    author = author,
                    content = c.content,
                    createdAt = c.createdAt
                )
            }
        }

    override suspend fun uploadVideo(
        authorId: String,
        title: String,
        kind: VideoKind,
        videoUri: String,
        durationSec: Long,
        allowDownload: Boolean
    ): Result<Unit> = runCatching {
        val cleanTitle = title.trim()
        require(cleanTitle.isNotBlank()) { "Video title is required" }
        dao.insertVideo(
            VideoEntity(
                id = UUID.randomUUID().toString(),
                authorId = authorId,
                title = cleanTitle,
                kind = kind.name,
                videoUri = videoUri,
                durationSec = durationSec,
                allowDownload = allowDownload,
                sharesCount = 0,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    override suspend fun toggleVideoLike(userId: String, videoId: String): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        if (dao.hasLikedVideo(videoId, userId) > 0) {
            dao.deleteVideoLike(videoId, userId)
        } else {
            dao.insertVideoLike(VideoLikeEntity(videoId, userId, now))
            val video = dao.getVideoById(videoId)
            val actor = dao.getUserById(userId)
            if (video != null && actor != null && video.authorId != userId) {
                dao.insertNotification(
                    NotificationEntity(
                        id = UUID.randomUUID().toString(),
                        userId = video.authorId,
                        actorId = userId,
                        actorName = actor.username,
                        messageAr = "أعجب ${actor.username} بفيديو لك",
                        messageEn = "${actor.username} liked your video",
                        read = false,
                        createdAt = now
                    )
                )
            }
        }
    }

    override suspend fun addVideoComment(userId: String, videoId: String, content: String): Result<Unit> = runCatching {
        val clean = content.trim()
        require(clean.isNotBlank()) { "Comment cannot be empty" }
        val now = System.currentTimeMillis()
        dao.insertComment(
            CommentEntity(
                id = UUID.randomUUID().toString(),
                targetId = videoId,
                targetType = "VIDEO",
                authorId = userId,
                content = clean,
                createdAt = now
            )
        )
    }

    override suspend fun incrementVideoShare(videoId: String): Result<Unit> = runCatching {
        dao.incrementVideoShare(videoId)
    }
}
