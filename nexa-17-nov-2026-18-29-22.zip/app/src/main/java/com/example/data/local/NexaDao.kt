package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NexaDao {

    // Users
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUsersIgnore(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun observeUserById(id: String): Flow<UserEntity?>

    @Query("SELECT * FROM users")
    fun observeAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id LIKE '%' || :query || '%' OR username LIKE '%' || :query || '%'")
    suspend fun searchUsers(query: String): List<UserEntity>

    @Query("SELECT COUNT(*) FROM users WHERE id = :id")
    suspend fun countUserById(id: String): Int

    @Query("SELECT COUNT(*) FROM users")
    suspend fun countAllUsers(): Int

    // Friendships & Requests
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriendship(friendship: FriendshipEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFriendshipsIgnore(friendships: List<FriendshipEntity>)

    @Query("DELETE FROM friendships WHERE (userId = :a AND friendId = :b) OR (userId = :b AND friendId = :a)")
    suspend fun deleteFriendshipPair(a: String, b: String)

    @Query("SELECT friendId FROM friendships WHERE userId = :userId")
    fun observeFriendIds(userId: String): Flow<List<String>>

    @Query("SELECT friendId FROM friendships WHERE userId = :userId")
    suspend fun getFriendIds(userId: String): List<String>

    @Query("SELECT COUNT(*) FROM friendships WHERE userId = :a AND friendId = :b")
    suspend fun isFriends(a: String, b: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriendRequest(request: FriendRequestEntity): Long

    @Query("SELECT * FROM friend_requests WHERE id = :id LIMIT 1")
    suspend fun getFriendRequestById(id: Long): FriendRequestEntity?

    @Query("SELECT * FROM friend_requests WHERE fromUserId = :fromId AND toUserId = :toId AND status = 'PENDING' LIMIT 1")
    suspend fun getPendingRequest(fromId: String, toId: String): FriendRequestEntity?

    @Query("SELECT * FROM friend_requests WHERE toUserId = :userId AND status = 'PENDING' ORDER BY createdAt DESC")
    fun observeIncomingRequests(userId: String): Flow<List<FriendRequestEntity>>

    @Query("UPDATE friend_requests SET status = :status WHERE id = :id")
    suspend fun updateFriendRequestStatus(id: Long, status: String)

    // Posts, Likes, Comments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPostsIgnore(posts: List<PostEntity>)

    @Query("DELETE FROM posts WHERE id = :postId AND authorId = :authorId")
    suspend fun deletePost(postId: String, authorId: String)

    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun observeAllPosts(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE authorId = :authorId ORDER BY createdAt DESC")
    fun observePostsByAuthor(authorId: String): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE content LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    suspend fun searchPosts(query: String): List<PostEntity>

    @Query("UPDATE posts SET sharesCount = sharesCount + 1 WHERE id = :postId")
    suspend fun incrementPostShare(postId: String)

    @Query("SELECT * FROM posts WHERE id = :postId LIMIT 1")
    suspend fun getPostById(postId: String): PostEntity?

    @Query("SELECT * FROM post_likes")
    fun observeAllPostLikes(): Flow<List<PostLikeEntity>>

    @Query("SELECT COUNT(*) FROM post_likes WHERE postId = :postId AND userId = :userId")
    suspend fun hasLikedPost(postId: String, userId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPostLike(like: PostLikeEntity)

    @Query("DELETE FROM post_likes WHERE postId = :postId AND userId = :userId")
    suspend fun deletePostLike(postId: String, userId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("SELECT * FROM comments WHERE targetType = :type")
    fun observeCommentsByType(type: String): Flow<List<CommentEntity>>

    @Query("SELECT * FROM comments WHERE targetId = :targetId AND targetType = :type ORDER BY createdAt ASC")
    fun observeCommentsForTarget(targetId: String, type: String): Flow<List<CommentEntity>>

    // Stories (24h expiration)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertStoriesIgnore(stories: List<StoryEntity>)

    @Query("SELECT * FROM stories WHERE expiresAt > :now ORDER BY createdAt DESC")
    fun observeActiveStories(now: Long): Flow<List<StoryEntity>>

    @Query("DELETE FROM stories WHERE expiresAt <= :now")
    suspend fun purgeExpiredStories(now: Long)

    // Messages
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessagesIgnore(messages: List<MessageEntity>)

    @Query("SELECT * FROM messages WHERE senderId = :userId OR receiverId = :userId ORDER BY createdAt DESC")
    fun observeUserMessages(userId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE (senderId = :a AND receiverId = :b) OR (senderId = :b AND receiverId = :a) ORDER BY createdAt ASC")
    fun observeThreadMessages(a: String, b: String): Flow<List<MessageEntity>>

    @Query("UPDATE messages SET status = :status WHERE senderId = :senderId AND receiverId = :receiverId AND status != 'READ'")
    suspend fun updateIncomingStatus(senderId: String, receiverId: String, status: String)

    // Videos
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertVideosIgnore(videos: List<VideoEntity>)

    @Query("SELECT * FROM videos WHERE kind = :kind ORDER BY createdAt DESC")
    fun observeVideosByKind(kind: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE title LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    suspend fun searchVideos(query: String): List<VideoEntity>

    @Query("SELECT * FROM videos WHERE id = :videoId LIMIT 1")
    suspend fun getVideoById(videoId: String): VideoEntity?

    @Query("UPDATE videos SET sharesCount = sharesCount + 1 WHERE id = :videoId")
    suspend fun incrementVideoShare(videoId: String)

    @Query("SELECT * FROM video_likes")
    fun observeAllVideoLikes(): Flow<List<VideoLikeEntity>>

    @Query("SELECT COUNT(*) FROM video_likes WHERE videoId = :videoId AND userId = :userId")
    suspend fun hasLikedVideo(videoId: String, userId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideoLike(like: VideoLikeEntity)

    @Query("DELETE FROM video_likes WHERE videoId = :videoId AND userId = :userId")
    suspend fun deleteVideoLike(videoId: String, userId: String)

    // Notifications
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeNotifications(userId: String): Flow<List<NotificationEntity>>

    @Query("UPDATE notifications SET read = 1 WHERE id = :id")
    suspend fun markNotificationRead(id: String)

    @Query("UPDATE notifications SET read = 1 WHERE userId = :userId")
    suspend fun markAllNotificationsRead(userId: String)

    // Block & Report
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlock(block: BlockEntity)

    @Query("DELETE FROM blocked_users WHERE blockerId = :blockerId AND blockedId = :blockedId")
    suspend fun deleteBlock(blockerId: String, blockedId: String)

    @Query("SELECT blockedId FROM blocked_users WHERE blockerId = :blockerId")
    fun observeBlockedIds(blockerId: String): Flow<List<String>>

    @Query("SELECT blockerId FROM blocked_users WHERE blockedId = :userId UNION SELECT blockedId FROM blocked_users WHERE blockerId = :userId")
    fun observeAnyBlockParticipantIds(userId: String): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM blocked_users WHERE (blockerId = :a AND blockedId = :b) OR (blockerId = :b AND blockedId = :a)")
    suspend fun isBlockedBetween(a: String, b: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity)
}
