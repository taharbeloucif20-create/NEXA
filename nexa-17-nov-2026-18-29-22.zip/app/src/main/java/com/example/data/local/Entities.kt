package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val username: String,
    val bio: String,
    val avatarUri: String?,
    val passwordHash: String,
    val profileVisibility: String,
    val allowFriendRequests: Boolean,
    val allowMessagesFrom: String,
    val showReadReceipts: Boolean,
    val allowVideoDownloadsDefault: Boolean,
    val createdAt: Long
)

@Entity(tableName = "friend_requests")
data class FriendRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromUserId: String,
    val toUserId: String,
    val status: String, // PENDING, ACCEPTED, DECLINED
    val createdAt: Long
)

@Entity(tableName = "friendships", primaryKeys = ["userId", "friendId"])
data class FriendshipEntity(
    val userId: String,
    val friendId: String,
    val createdAt: Long
)

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val content: String,
    val imageUri: String?,
    val sharesCount: Int = 0,
    val createdAt: Long
)

@Entity(tableName = "post_likes", primaryKeys = ["postId", "userId"])
data class PostLikeEntity(
    val postId: String,
    val userId: String,
    val createdAt: Long
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey val id: String,
    val targetId: String, // postId or videoId
    val targetType: String, // POST or VIDEO
    val authorId: String,
    val content: String,
    val createdAt: Long
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val caption: String,
    val imageUri: String?,
    val createdAt: Long,
    val expiresAt: Long
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val senderId: String,
    val receiverId: String,
    val type: String, // TEXT, IMAGE, VOICE, CALL_VOICE, CALL_VIDEO
    val textContent: String,
    val mediaUri: String?,
    val durationSec: Long,
    val status: String, // SENT, DELIVERED, READ
    val createdAt: Long
)

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val title: String,
    val kind: String, // REEL, LONG
    val videoUri: String,
    val durationSec: Long,
    val allowDownload: Boolean,
    val sharesCount: Int = 0,
    val createdAt: Long
)

@Entity(tableName = "video_likes", primaryKeys = ["videoId", "userId"])
data class VideoLikeEntity(
    val videoId: String,
    val userId: String,
    val createdAt: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val actorId: String,
    val actorName: String,
    val messageAr: String,
    val messageEn: String,
    val read: Boolean,
    val createdAt: Long
)

@Entity(tableName = "blocked_users", primaryKeys = ["blockerId", "blockedId"])
data class BlockEntity(
    val blockerId: String,
    val blockedId: String,
    val createdAt: Long
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val reporterId: String,
    val targetUserId: String,
    val targetContentId: String?,
    val reason: String,
    val details: String,
    val createdAt: Long
)
