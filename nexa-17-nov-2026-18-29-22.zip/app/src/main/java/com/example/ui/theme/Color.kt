package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Monochrome Black & White Palette
val ObsidianBlack = Color(0xFF09090B)
val OnyxSurface = Color(0xFF131316)
val GraphiteSurface = Color(0xFF1C1C21)
val CharcoalElevated = Color(0xFF27272A)
val PureWhite = Color(0xFFFFFFFF)
val AlabasterWhite = Color(0xFFFAFAFA)
val MistSurface = Color(0xFFF4F4F5)
val SilverBorder = Color(0xFFE4E4E7)
val ZincMutedLight = Color(0xFF52525B)
val ZincMutedDark = Color(0xFFA1A1AA)
val HairlineDark = Color(0xFF27272A)
val HairlineLight = Color(0xFFE4E4E7)
val CrispDangerDark = Color(0xFFE4E4E7)
val CrispDangerLight = Color(0xFF18181B)
