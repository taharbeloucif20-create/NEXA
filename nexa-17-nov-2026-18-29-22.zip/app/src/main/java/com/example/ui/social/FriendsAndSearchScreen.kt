package com.example.ui.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.LocalNexaStrings
import com.example.domain.model.UserProfile
import com.example.ui.components.NexaAvatar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsAndSearchScreen(
    viewModel: SocialViewModel,
    initialTab: Int = 0,
    onOpenUserProfile: (String) -> Unit,
    onOpenChat: (String) -> Unit
) {
    val strings = LocalNexaStrings.current
    val friends by viewModel.friends.collectAsStateWithLifecycle()
    val requests by viewModel.incomingRequests.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val results by viewModel.searchResults.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var directIdInput by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        viewModel.feedback.collect { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.navNetwork,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 620.dp)
            ) {
                // Direct Add Friend by Unique ID Card
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(strings.addFriendByIdTitle, style = MaterialTheme.typography.labelLarge)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = directIdInput,
                                onValueChange = { directIdInput = it },
                                placeholder = { Text(strings.enterFriendId) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("add_friend_id_input"),
                                shape = RoundedCornerShape(14.dp)
                            )
                            Button(
                                onClick = {
                                    if (directIdInput.isNotBlank()) {
                                        viewModel.sendFriendRequestById(
                                            targetId = directIdInput,
                                            sentMsg = strings.requestSent,
                                            notFoundMsg = strings.userNotFound,
                                            selfMsg = strings.cannotAddSelf,
                                            alreadyFriendsMsg = strings.alreadyFriends
                                        )
                                        directIdInput = ""
                                    }
                                },
                                modifier = Modifier
                                    .heightIn(min = 52.dp)
                                    .testTag("send_friend_request_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(strings.sendRequest)
                            }
                        }
                    }
                }

                // Segmented Subtabs: Friends | Requests | Search
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(4.dp)
                ) {
                    val tabs = listOf(
                        "${strings.friendsTab} (${friends.size})",
                        "${strings.friendRequestsTab} (${requests.size})",
                        strings.searchTab
                    )
                    tabs.forEachIndexed { idx, label ->
                        val selected = selectedTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                .clickable { selectedTab = idx }
                                .testTag("social_tab_$idx"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                when (selectedTab) {
                    0 -> {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (friends.isEmpty()) {
                                item {
                                    EmptySocialCard(strings.startChatWithFriends)
                                }
                            } else {
                                items(friends, key = { it.id }) { friend ->
                                    UserRowCard(
                                        user = friend,
                                        onClick = { onOpenUserProfile(friend.id) },
                                        trailing = {
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                IconButton(
                                                    onClick = { onOpenChat(friend.id) },
                                                    modifier = Modifier.size(48.dp)
                                                ) {
                                                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = strings.messageAction)
                                                }
                                                IconButton(
                                                    onClick = { viewModel.removeFriend(friend.id) },
                                                    modifier = Modifier.size(48.dp)
                                                ) {
                                                    Icon(Icons.Default.PersonRemove, contentDescription = strings.removeFriend)
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                    1 -> {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (requests.isEmpty()) {
                                item {
                                    EmptySocialCard(strings.friendRequestsTab)
                                }
                            } else {
                                items(requests, key = { it.id }) { req ->
                                    UserRowCard(
                                        user = req.fromUser,
                                        onClick = { onOpenUserProfile(req.fromUser.id) },
                                        trailing = {
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Button(
                                                    onClick = { viewModel.acceptRequest(req.id) },
                                                    modifier = Modifier.heightIn(min = 44.dp).testTag("accept_request_${req.id}")
                                                ) {
                                                    Text(strings.accept)
                                                }
                                                OutlinedButton(
                                                    onClick = { viewModel.declineRequest(req.id) },
                                                    modifier = Modifier.heightIn(min = 44.dp).testTag("decline_request_${req.id}")
                                                ) {
                                                    Text(strings.decline)
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                    else -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            OutlinedTextField(
                                value = query,
                                onValueChange = viewModel::onSearchQueryChanged,
                                placeholder = { Text(strings.searchPlaceholder) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                                    .testTag("global_search_input"),
                                shape = RoundedCornerShape(16.dp)
                            )
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(results.users, key = { "u_${it.id}" }) { user ->
                                    UserRowCard(
                                        user = user,
                                        onClick = { onOpenUserProfile(user.id) },
                                        trailing = {
                                            IconButton(
                                                onClick = {
                                                    viewModel.sendFriendRequestById(
                                                        targetId = user.id,
                                                        sentMsg = strings.requestSent,
                                                        notFoundMsg = strings.userNotFound,
                                                        selfMsg = strings.cannotAddSelf,
                                                        alreadyFriendsMsg = strings.alreadyFriends
                                                    )
                                                },
                                                modifier = Modifier.size(48.dp)
                                            ) {
                                                Icon(Icons.Default.PersonAdd, contentDescription = strings.sendRequest)
                                            }
                                        }
                                    )
                                }
                                items(results.posts, key = { "p_${it.id}" }) { post ->
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                            .clickable { onOpenUserProfile(post.author.id) }
                                    ) {
                                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(post.author.username, style = MaterialTheme.typography.labelLarge)
                                            Text(post.content, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                                items(results.videos, key = { "v_${it.id}" }) { video ->
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                            .clickable { onOpenUserProfile(video.author.id) }
                                    ) {
                                        Row(
                                            Modifier.padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Icon(Icons.Default.PlayCircle, contentDescription = null)
                                            Column(Modifier.weight(1f)) {
                                                Text(video.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(video.author.username, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UserRowCard(
    user: UserProfile,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NexaAvatar(avatarUri = user.avatarUri, username = user.username, size = 46.dp)
            Column(modifier = Modifier.weight(1f)) {
                Text(user.username, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(user.id, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            trailing()
        }
    }
}

@Composable
private fun EmptySocialCard(text: String) {
    Box(
        modifier = Modifier.fillMaxWidth().padding(40.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
