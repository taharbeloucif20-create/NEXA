package com.example.ui.videos

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.media.MediaHelper
import com.example.domain.model.CommentItem
import com.example.domain.model.VideoItem
import com.example.domain.model.VideoKind
import com.example.domain.repository.VideoRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class VideosViewModel(
    private val currentUserId: String,
    private val videoRepository: VideoRepository,
    private val mediaHelper: MediaHelper
) : ViewModel() {

    private val _selectedKind = MutableStateFlow(VideoKind.REEL)
    val selectedKind: StateFlow<VideoKind> = _selectedKind.asStateFlow()

    val reels: StateFlow<List<VideoItem>> = videoRepository.observeVideos(currentUserId, VideoKind.REEL)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val longVideos: StateFlow<List<VideoItem>> = videoRepository.observeVideos(currentUserId, VideoKind.LONG)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeCommentVideoId = MutableStateFlow<String?>(null)
    val activeCommentVideoId: StateFlow<String?> = _activeCommentVideoId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeComments: StateFlow<List<CommentItem>> = _activeCommentVideoId
        .flatMapLatest { vid ->
            if (vid == null) flowOf(emptyList())
            else videoRepository.observeVideoComments(vid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _feedback = MutableSharedFlow<String>()
    val feedback: SharedFlow<String> = _feedback.asSharedFlow()

    fun selectKind(kind: VideoKind) {
        _selectedKind.value = kind
    }

    fun toggleLike(videoId: String) {
        viewModelScope.launch {
            videoRepository.toggleVideoLike(currentUserId, videoId)
        }
    }

    fun openComments(videoId: String) {
        _activeCommentVideoId.value = videoId
    }

    fun closeComments() {
        _activeCommentVideoId.value = null
    }

    fun addComment(content: String) {
        val vid = _activeCommentVideoId.value ?: return
        viewModelScope.launch {
            videoRepository.addVideoComment(currentUserId, vid, content)
        }
    }

    fun recordShare(videoId: String) {
        viewModelScope.launch {
            videoRepository.incrementVideoShare(videoId)
        }
    }

    fun uploadVideo(title: String, kind: VideoKind, pickedUri: Uri, allowDownload: Boolean) {
        viewModelScope.launch {
            val saved = mediaHelper.persistPickedVideo(pickedUri)
            saved.onSuccess { (storedUri, durationSec) ->
                videoRepository.uploadVideo(
                    authorId = currentUserId,
                    title = title,
                    kind = kind,
                    videoUri = storedUri,
                    durationSec = durationSec,
                    allowDownload = allowDownload
                )
            }.onFailure { err ->
                _feedback.emit(err.message ?: "Upload failed")
            }
        }
    }

    fun downloadVideo(video: VideoItem, successMsg: String, disabledMsg: String) {
        viewModelScope.launch {
            if (!video.allowDownload) {
                _feedback.emit(disabledMsg)
                return@launch
            }
            val result = mediaHelper.saveVideoToGallery(video.videoUri, video.title)
            result.onSuccess {
                _feedback.emit(successMsg)
            }.onFailure { e ->
                _feedback.emit(e.message ?: "Download failed")
            }
        }
    }
}
