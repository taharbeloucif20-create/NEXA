package com.example.ui.home

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.media.MediaHelper
import com.example.domain.model.CommentItem
import com.example.domain.model.PostItem
import com.example.domain.model.ReportReason
import com.example.domain.model.StoryGroup
import com.example.domain.model.UserProfile
import com.example.domain.repository.SocialRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HomeViewModel(
    private val currentUserId: String,
    private val socialRepository: SocialRepository,
    private val mediaHelper: MediaHelper
) : ViewModel() {

    val posts: StateFlow<List<PostItem>> = socialRepository.observeFeedPosts(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storyGroups: StateFlow<List<StoryGroup>> = socialRepository.observeActiveStories(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = socialRepository.observeNotifications(currentUserId)
        .map { list -> list.count { !it.read } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _activeCommentPostId = MutableStateFlow<String?>(null)
    val activeCommentPostId: StateFlow<String?> = _activeCommentPostId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeComments: StateFlow<List<CommentItem>> = _activeCommentPostId
        .flatMapLatest { postId ->
            if (postId == null) flowOf(emptyList())
            else socialRepository.observePostComments(postId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _feedbackMessage = MutableSharedFlow<String>()
    val feedbackMessage: SharedFlow<String> = _feedbackMessage.asSharedFlow()

    init {
        viewModelScope.launch {
            socialRepository.purgeExpiredStories()
        }
    }

    fun openComments(postId: String) {
        _activeCommentPostId.value = postId
    }

    fun closeComments() {
        _activeCommentPostId.value = null
    }

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            socialRepository.togglePostLike(currentUserId, postId)
        }
    }

    fun addComment(content: String) {
        val postId = _activeCommentPostId.value ?: return
        viewModelScope.launch {
            socialRepository.addPostComment(currentUserId, postId, content)
        }
    }

    fun recordShare(postId: String) {
        viewModelScope.launch {
            socialRepository.incrementPostShare(postId)
        }
    }

    fun createPost(content: String, pickedImageUri: Uri?) {
        viewModelScope.launch {
            val savedUri = if (pickedImageUri != null) {
                mediaHelper.persistPickedImage(pickedImageUri).getOrNull()
            } else null
            socialRepository.createPost(currentUserId, content, savedUri)
        }
    }

    fun deletePost(postId: String) {
        viewModelScope.launch {
            socialRepository.deletePost(currentUserId, postId)
        }
    }

    fun createStory(caption: String, pickedImageUri: Uri?) {
        viewModelScope.launch {
            val savedUri = if (pickedImageUri != null) {
                mediaHelper.persistPickedImage(pickedImageUri).getOrNull()
            } else null
            socialRepository.createStory(currentUserId, caption, savedUri)
        }
    }

    fun blockUser(targetUser: UserProfile, confirmMsg: String) {
        viewModelScope.launch {
            socialRepository.blockUser(currentUserId, targetUser.id)
            _feedbackMessage.emit(confirmMsg)
        }
    }

    fun reportUser(targetUser: UserProfile, contentId: String?, reason: ReportReason, details: String, confirmMsg: String) {
        viewModelScope.launch {
            socialRepository.reportUserOrContent(currentUserId, targetUser.id, contentId, reason, details)
            _feedbackMessage.emit(confirmMsg)
        }
    }
}
