package com.example.ui.videos

import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.LocalNexaStrings
import com.example.domain.model.VideoItem
import com.example.domain.model.VideoKind
import com.example.ui.components.CommentsBottomSheet
import com.example.ui.components.NexaAvatar
import com.example.ui.components.formatRelativeTime
import com.example.ui.components.shareTextExternally

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideosScreen(
    viewModel: VideosViewModel,
    onOpenUserProfile: (String) -> Unit
) {
    val strings = LocalNexaStrings.current
    val context = LocalContext.current
    val selectedKind by viewModel.selectedKind.collectAsStateWithLifecycle()
    val reels by viewModel.reels.collectAsStateWithLifecycle()
    val longVideos by viewModel.longVideos.collectAsStateWithLifecycle()
    val activeCommentVideoId by viewModel.activeCommentVideoId.collectAsStateWithLifecycle()
    val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showUploadDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.feedback.collect { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(3.dp)
                    ) {
                        listOf(
                            VideoKind.REEL to strings.reelsTab,
                            VideoKind.LONG to strings.longVideosTab
                        ).forEach { (kind, label) ->
                            val selected = selectedKind == kind
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { viewModel.selectKind(kind) }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                                    .testTag("video_tab_${kind.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showUploadDialog = true },
                        modifier = Modifier.size(48.dp).testTag("upload_video_button")
                    ) {
                        Icon(Icons.Default.VideoCall, contentDescription = strings.uploadVideo)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (selectedKind == VideoKind.REEL) {
                if (reels.isEmpty()) {
                    EmptyVideosPlaceholder()
                } else {
                    val pagerState = rememberPagerState(pageCount = { reels.size })
                    VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize().widthIn(max = 540.dp)
                    ) { page ->
                        val video = reels[page]
                        val isCurrentPage = pagerState.currentPage == page
                        ReelPage(
                            video = video,
                            isActive = isCurrentPage,
                            onAuthorClick = { onOpenUserProfile(video.author.id) },
                            onLike = { viewModel.toggleLike(video.id) },
                            onComment = { viewModel.openComments(video.id) },
                            onShare = {
                                viewModel.recordShare(video.id)
                                shareTextExternally(context, video.title, "${video.author.username}: ${video.title}")
                            },
                            onDownload = {
                                viewModel.downloadVideo(
                                    video,
                                    strings.videoSavedToGallery,
                                    strings.downloadDisabledByCreator
                                )
                            }
                        )
                    }
                }
            } else {
                if (longVideos.isEmpty()) {
                    EmptyVideosPlaceholder()
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().widthIn(max = 620.dp),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(longVideos, key = { it.id }) { video ->
                            LongVideoCard(
                                video = video,
                                onAuthorClick = { onOpenUserProfile(video.author.id) },
                                onLike = { viewModel.toggleLike(video.id) },
                                onComment = { viewModel.openComments(video.id) },
                                onShare = {
                                    viewModel.recordShare(video.id)
                                    shareTextExternally(context, video.title, "${video.author.username}: ${video.title}")
                                },
                                onDownload = {
                                    viewModel.downloadVideo(
                                        video,
                                        strings.videoSavedToGallery,
                                        strings.downloadDisabledByCreator
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showUploadDialog) {
        UploadVideoDialog(
            onDismiss = { showUploadDialog = false },
            onUpload = { title, kind, uri, allowDownload ->
                viewModel.uploadVideo(title, kind, uri, allowDownload)
                showUploadDialog = false
            }
        )
    }

    if (activeCommentVideoId != null) {
        CommentsBottomSheet(
            comments = activeComments,
            onDismiss = { viewModel.closeComments() },
            onSubmitComment = { viewModel.addComment(it) }
        )
    }
}

@Composable
private fun ReelPage(
    video: VideoItem,
    isActive: Boolean,
    onAuthorClick: () -> Unit,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onShare: () -> Unit,
    onDownload: () -> Unit
) {
    val strings = LocalNexaStrings.current
    var isPaused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { isPaused = !isPaused }
    ) {
        PlayableVideoSurface(
            videoUri = video.videoUri,
            shouldPlay = isActive && !isPaused,
            looping = true,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f))
                    )
                )
        )

        if (isPaused) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(64.dp).align(Alignment.Center)
            )
        }

        // Action column
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 14.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ReelActionIcon(
                icon = if (video.likedByMe) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                label = "${video.likesCount}",
                onClick = onLike,
                tag = "like_reel_${video.id}"
            )
            ReelActionIcon(
                icon = Icons.AutoMirrored.Filled.Chat,
                label = "${video.commentsCount}",
                onClick = onComment,
                tag = "comment_reel_${video.id}"
            )
            ReelActionIcon(
                icon = Icons.Default.Share,
                label = "${video.sharesCount}",
                onClick = onShare,
                tag = "share_reel_${video.id}"
            )
            ReelActionIcon(
                icon = if (video.allowDownload) Icons.Default.Download else Icons.Default.Lock,
                label = if (video.allowDownload) strings.downloadToGallery else "",
                onClick = onDownload,
                tag = "download_reel_${video.id}"
            )
        }

        // Author & caption
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, end = 88.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.clickable { onAuthorClick() }
            ) {
                NexaAvatar(avatarUri = video.author.avatarUri, username = video.author.username, size = 38.dp)
                Text(
                    text = "${video.author.username} • ${video.author.id}",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )
            }
            Text(
                text = video.title,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.92f),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ReelActionIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.55f))
                .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White)
        }
        if (label.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White)
        }
    }
}

@Composable
private fun LongVideoCard(
    video: VideoItem,
    onAuthorClick: () -> Unit,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onShare: () -> Unit,
    onDownload: () -> Unit
) {
    val strings = LocalNexaStrings.current
    var isPlaying by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
                    .clickable { isPlaying = !isPlaying }
            ) {
                PlayableVideoSurface(
                    videoUri = video.videoUri,
                    shouldPlay = isPlaying,
                    looping = false,
                    modifier = Modifier.fillMaxSize()
                )
                if (!isPlaying) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .align(Alignment.Center)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.72f))
                            .border(1.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)
                ) {
                    Text(
                        text = "${video.durationSec}s",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(video.title, style = MaterialTheme.typography.titleMedium)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.clickable { onAuthorClick() }
                ) {
                    NexaAvatar(avatarUri = video.author.avatarUri, username = video.author.username, size = 32.dp)
                    Text(
                        text = "${video.author.username} • ${formatRelativeTime(video.createdAt, strings.isArabic)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onLike, modifier = Modifier.heightIn(min = 48.dp)) {
                        Icon(
                            if (video.likedByMe) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = strings.likes,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("${video.likesCount}")
                    }
                    TextButton(onClick = onComment, modifier = Modifier.heightIn(min = 48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = strings.comments, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("${video.commentsCount}")
                    }
                    TextButton(onClick = onShare, modifier = Modifier.heightIn(min = 48.dp)) {
                        Icon(Icons.Default.Share, contentDescription = strings.shares, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("${video.sharesCount}")
                    }
                    IconButton(
                        onClick = onDownload,
                        modifier = Modifier.size(48.dp).testTag("download_long_${video.id}")
                    ) {
                        Icon(
                            imageVector = if (video.allowDownload) Icons.Default.Download else Icons.Default.Lock,
                            contentDescription = strings.downloadToGallery
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayableVideoSurface(
    videoUri: String,
    shouldPlay: Boolean,
    looping: Boolean,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx ->
            VideoView(ctx).apply {
                setVideoURI(videoUri.toUri())
                setOnPreparedListener { mp ->
                    mp.isLooping = looping
                    if (shouldPlay) start() else seekTo(100)
                }
            }
        },
        update = { view ->
            if (shouldPlay && !view.isPlaying) {
                view.start()
            } else if (!shouldPlay && view.isPlaying) {
                view.pause()
            }
        },
        modifier = modifier
    )
}

@Composable
private fun UploadVideoDialog(
    onDismiss: () -> Unit,
    onUpload: (String, VideoKind, Uri, Boolean) -> Unit
) {
    val strings = LocalNexaStrings.current
    var title by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(VideoKind.REEL) }
    var allowDownload by remember { mutableStateOf(true) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pickedUri = uri }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.uploadVideo) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(strings.videoTitleLabel) },
                    modifier = Modifier.fillMaxWidth().testTag("upload_video_title_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = kind == VideoKind.REEL,
                        onClick = { kind = VideoKind.REEL },
                        label = { Text(strings.reelType) }
                    )
                    FilterChip(
                        selected = kind == VideoKind.LONG,
                        onClick = { kind = VideoKind.LONG },
                        label = { Text(strings.longVideoType) }
                    )
                }
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("pick_video_button")
                ) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (pickedUri != null) "✓ ${strings.selectVideo}" else strings.selectVideo)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.allowDownloadLabel, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = allowDownload, onCheckedChange = { allowDownload = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { pickedUri?.let { onUpload(title, kind, it, allowDownload) } },
                enabled = title.isNotBlank() && pickedUri != null,
                modifier = Modifier.testTag("confirm_upload_video_button")
            ) {
                Text(strings.publish)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
private fun EmptyVideosPlaceholder() {
    val strings = LocalNexaStrings.current
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(48.dp))
            Text(strings.noVideosYet, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
