package com.example.ui.profile

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.i18n.AppLanguage
import com.example.core.media.MediaHelper
import com.example.domain.model.*
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.SettingsRepository
import com.example.domain.repository.SocialRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val currentUserId: String,
    private val authRepository: AuthRepository,
    private val socialRepository: SocialRepository,
    private val settingsRepository: SettingsRepository,
    private val mediaHelper: MediaHelper
) : ViewModel() {

    val currentUser: StateFlow<UserProfile?> = authRepository.observeCurrentUser()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val ownPosts: StateFlow<List<PostItem>> = socialRepository.observeUserPosts(currentUserId, currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val friends: StateFlow<List<UserProfile>> = socialRepository.observeFriends(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = socialRepository.observeNotifications(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blockedUsers: StateFlow<List<UserProfile>> = socialRepository.observeBlockedUsers(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isDarkTheme: StateFlow<Boolean> = settingsRepository.isDarkTheme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val language: StateFlow<AppLanguage> = settingsRepository.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.ARABIC)

    private val _feedback = MutableSharedFlow<String>()
    val feedback: SharedFlow<String> = _feedback.asSharedFlow()

    fun observeTargetUser(targetUserId: String): Flow<UserProfile?> =
        socialRepository.observeUser(targetUserId)

    fun observeTargetPosts(targetUserId: String): Flow<List<PostItem>> =
        socialRepository.observeUserPosts(currentUserId, targetUserId)

    suspend fun getFriendshipState(targetUserId: String): FriendshipState =
        socialRepository.getFriendshipState(currentUserId, targetUserId)

    fun updateProfile(username: String, bio: String, pickedAvatarUri: Uri?) {
        viewModelScope.launch {
            val savedAvatar = if (pickedAvatarUri != null) {
                mediaHelper.persistPickedImage(pickedAvatarUri).getOrNull()
            } else null
            authRepository.updateProfile(username, bio, savedAvatar)
        }
    }

    fun signOut() {
        viewModelScope.launch {
            authRepository.signOut()
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setDarkTheme(enabled) }
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch { settingsRepository.setLanguage(lang) }
    }

    fun updatePrivacy(
        profileVisibility: PrivacyScope,
        allowFriendRequests: Boolean,
        allowMessagesFrom: PrivacyScope,
        showReadReceipts: Boolean,
        allowVideoDownloadsDefault: Boolean
    ) {
        viewModelScope.launch {
            settingsRepository.updatePrivacySettings(
                userId = currentUserId,
                profileVisibility = profileVisibility,
                allowFriendRequests = allowFriendRequests,
                allowMessagesFrom = allowMessagesFrom,
                showReadReceipts = showReadReceipts,
                allowVideoDownloadsDefault = allowVideoDownloadsDefault
            )
        }
    }

    fun sendFriendRequest(targetId: String, sentMsg: String) {
        viewModelScope.launch {
            socialRepository.sendFriendRequest(currentUserId, targetId)
                .onSuccess { _feedback.emit(sentMsg) }
                .onFailure { _feedback.emit(it.message ?: "Error") }
        }
    }

    fun removeFriend(targetId: String) {
        viewModelScope.launch {
            socialRepository.removeFriend(currentUserId, targetId)
        }
    }

    fun blockUser(targetId: String, blockedMsg: String) {
        viewModelScope.launch {
            socialRepository.blockUser(currentUserId, targetId)
            _feedback.emit(blockedMsg)
        }
    }

    fun unblockUser(targetId: String) {
        viewModelScope.launch {
            socialRepository.unblockUser(currentUserId, targetId)
        }
    }

    fun reportUser(targetId: String, reason: ReportReason, details: String, confirmMsg: String) {
        viewModelScope.launch {
            socialRepository.reportUserOrContent(currentUserId, targetId, null, reason, details)
            _feedback.emit(confirmMsg)
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch { socialRepository.markNotificationRead(id) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch { socialRepository.markAllNotificationsRead(currentUserId) }
    }
}
