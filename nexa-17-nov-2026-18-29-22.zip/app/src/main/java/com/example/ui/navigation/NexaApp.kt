package com.example.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.AppContainer
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.ArabicStrings
import com.example.core.i18n.EnglishStrings
import com.example.core.i18n.LocalNexaStrings
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthViewModel
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.messaging.CallScreen
import com.example.ui.messaging.ChatScreen
import com.example.ui.messaging.ConversationsScreen
import com.example.ui.messaging.MessagingViewModel
import com.example.ui.profile.*
import com.example.ui.social.FriendsAndSearchScreen
import com.example.ui.social.SocialViewModel
import com.example.ui.theme.NexaTheme
import com.example.ui.videos.VideosScreen
import com.example.ui.videos.VideosViewModel

object NexaRoutes {
    const val FEED = "feed"
    const val VIDEOS = "videos"
    const val MESSAGES = "messages"
    const val NETWORK = "network"
    const val NETWORK_SEARCH = "network_search"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"
    const val PRIVACY = "privacy"
    const val USER_PROFILE = "user/{userId}"
    const val CHAT = "chat/{peerId}"
    const val CALL = "call/{peerId}/{isVideo}"

    fun userProfile(userId: String) = "user/$userId"
    fun chat(peerId: String) = "chat/$peerId"
    fun call(peerId: String, isVideo: Boolean) = "call/$peerId/$isVideo"
}

private data class TopTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

@Composable
fun NexaApp(container: AppContainer) {
    val isDarkTheme by container.settingsRepository.isDarkTheme
        .collectAsStateWithLifecycle(initialValue = true)
    val language by container.settingsRepository.language
        .collectAsStateWithLifecycle(initialValue = AppLanguage.ARABIC)
    val currentUserId by container.authRepository.currentUserId
        .collectAsStateWithLifecycle(initialValue = null)

    val strings = if (language == AppLanguage.ARABIC) ArabicStrings else EnglishStrings

    CompositionLocalProvider(
        LocalLayoutDirection provides language.layoutDirection,
        LocalNexaStrings provides strings
    ) {
        NexaTheme(darkTheme = isDarkTheme) {
            val authViewModel: AuthViewModel = viewModel(
                factory = viewModelFactory {
                    initializer {
                        AuthViewModel(container.authRepository, container.settingsRepository)
                    }
                }
            )
            val authUiState by authViewModel.uiState.collectAsStateWithLifecycle()

            val activeUid = currentUserId
            if (activeUid.isNullOrBlank() || authUiState.newlyRegisteredUser != null) {
                AuthScreen(
                    viewModel = authViewModel,
                    isDarkTheme = isDarkTheme,
                    language = language,
                    onRegistrationAcknowledged = { authViewModel.dismissRegisteredCard() }
                )
            } else {
                key(activeUid) {
                    MainAuthenticatedShell(
                        container = container,
                        currentUserId = activeUid
                    )
                }
            }
        }
    }
}

@Composable
private fun MainAuthenticatedShell(
    container: AppContainer,
    currentUserId: String
) {
    val strings = LocalNexaStrings.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val homeViewModel: HomeViewModel = viewModel(
        key = "home_$currentUserId",
        factory = viewModelFactory {
            initializer { HomeViewModel(currentUserId, container.socialRepository, container.mediaHelper) }
        }
    )
    val videosViewModel: VideosViewModel = viewModel(
        key = "videos_$currentUserId",
        factory = viewModelFactory {
            initializer { VideosViewModel(currentUserId, container.videoRepository, container.mediaHelper) }
        }
    )
    val messagingViewModel: MessagingViewModel = viewModel(
        key = "messaging_$currentUserId",
        factory = viewModelFactory {
            initializer {
                MessagingViewModel(
                    currentUserId = currentUserId,
                    messagingRepository = container.messagingRepository,
                    socialRepository = container.socialRepository,
                    mediaHelper = container.mediaHelper,
                    voiceRecorder = container.voiceRecorderManager,
                    voicePlayer = container.voicePlayerManager
                )
            }
        }
    )
    val socialViewModel: SocialViewModel = viewModel(
        key = "social_$currentUserId",
        factory = viewModelFactory {
            initializer { SocialViewModel(currentUserId, container.socialRepository) }
        }
    )
    val profileViewModel: ProfileViewModel = viewModel(
        key = "profile_$currentUserId",
        factory = viewModelFactory {
            initializer {
                ProfileViewModel(
                    currentUserId = currentUserId,
                    authRepository = container.authRepository,
                    socialRepository = container.socialRepository,
                    settingsRepository = container.settingsRepository,
                    mediaHelper = container.mediaHelper
                )
            }
        }
    )

    val topTabs = listOf(
        TopTab(NexaRoutes.FEED, strings.navFeed, Icons.Filled.Home, Icons.Outlined.Home, "nav_feed"),
        TopTab(NexaRoutes.VIDEOS, strings.navVideos, Icons.Filled.PlayCircle, Icons.Outlined.PlayCircle, "nav_videos"),
        TopTab(NexaRoutes.MESSAGES, strings.navMessages, Icons.AutoMirrored.Filled.Chat, Icons.AutoMirrored.Outlined.Chat, "nav_messages"),
        TopTab(NexaRoutes.NETWORK, strings.navNetwork, Icons.Filled.Group, Icons.Outlined.Group, "nav_network"),
        TopTab(NexaRoutes.PROFILE, strings.navProfile, Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
    )

    val showTopLevelNav = currentRoute in setOf(
        NexaRoutes.FEED,
        NexaRoutes.VIDEOS,
        NexaRoutes.MESSAGES,
        NexaRoutes.NETWORK,
        NexaRoutes.PROFILE
    )

    fun navigateTopTab(route: String) {
        navController.navigate(route) {
            popUpTo(NexaRoutes.FEED) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showTopLevelNav && !useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp
                    ) {
                        topTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelNav && useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(Modifier.height(16.dp))
                        topTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = NexaRoutes.FEED,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                ) {
                    composable(NexaRoutes.FEED) {
                        HomeScreen(
                            viewModel = homeViewModel,
                            currentUserId = currentUserId,
                            onOpenNotifications = { navController.navigate(NexaRoutes.NOTIFICATIONS) },
                            onOpenSearch = { navController.navigate(NexaRoutes.NETWORK_SEARCH) },
                            onOpenUserProfile = { uid ->
                                if (uid == currentUserId) navigateTopTab(NexaRoutes.PROFILE)
                                else navController.navigate(NexaRoutes.userProfile(uid))
                            }
                        )
                    }
                    composable(NexaRoutes.VIDEOS) {
                        VideosScreen(
                            viewModel = videosViewModel,
                            onOpenUserProfile = { uid ->
                                if (uid == currentUserId) navigateTopTab(NexaRoutes.PROFILE)
                                else navController.navigate(NexaRoutes.userProfile(uid))
                            }
                        )
                    }
                    composable(NexaRoutes.MESSAGES) {
                        ConversationsScreen(
                            viewModel = messagingViewModel,
                            currentUserId = currentUserId,
                            onOpenChat = { peerId -> navController.navigate(NexaRoutes.chat(peerId)) }
                        )
                    }
                    composable(NexaRoutes.NETWORK) {
                        FriendsAndSearchScreen(
                            viewModel = socialViewModel,
                            initialTab = 0,
                            onOpenUserProfile = { uid ->
                                if (uid == currentUserId) navigateTopTab(NexaRoutes.PROFILE)
                                else navController.navigate(NexaRoutes.userProfile(uid))
                            },
                            onOpenChat = { peerId -> navController.navigate(NexaRoutes.chat(peerId)) }
                        )
                    }
                    composable(NexaRoutes.NETWORK_SEARCH) {
                        FriendsAndSearchScreen(
                            viewModel = socialViewModel,
                            initialTab = 2,
                            onOpenUserProfile = { uid ->
                                if (uid == currentUserId) navigateTopTab(NexaRoutes.PROFILE)
                                else navController.navigate(NexaRoutes.userProfile(uid))
                            },
                            onOpenChat = { peerId -> navController.navigate(NexaRoutes.chat(peerId)) }
                        )
                    }
                    composable(NexaRoutes.PROFILE) {
                        OwnProfileScreen(
                            viewModel = profileViewModel,
                            onOpenPrivacySettings = { navController.navigate(NexaRoutes.PRIVACY) },
                            onOpenNotifications = { navController.navigate(NexaRoutes.NOTIFICATIONS) }
                        )
                    }
                    composable(NexaRoutes.NOTIFICATIONS) {
                        NotificationsScreen(
                            viewModel = profileViewModel,
                            onBack = { navController.popBackStack() },
                            onOpenUserProfile = { uid ->
                                if (uid == currentUserId) navigateTopTab(NexaRoutes.PROFILE)
                                else navController.navigate(NexaRoutes.userProfile(uid))
                            }
                        )
                    }
                    composable(NexaRoutes.PRIVACY) {
                        PrivacySettingsScreen(
                            viewModel = profileViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                    composable(
                        route = NexaRoutes.USER_PROFILE,
                        arguments = listOf(navArgument("userId") { type = NavType.StringType })
                    ) { entry ->
                        val uid = entry.arguments?.getString("userId") ?: return@composable
                        UserProfileScreen(
                            viewModel = profileViewModel,
                            targetUserId = uid,
                            onBack = { navController.popBackStack() },
                            onOpenChat = { peerId -> navController.navigate(NexaRoutes.chat(peerId)) }
                        )
                    }
                    composable(
                        route = NexaRoutes.CHAT,
                        arguments = listOf(navArgument("peerId") { type = NavType.StringType })
                    ) { entry ->
                        val peerId = entry.arguments?.getString("peerId") ?: return@composable
                        ChatScreen(
                            viewModel = messagingViewModel,
                            currentUserId = currentUserId,
                            peerId = peerId,
                            onBack = { navController.popBackStack() },
                            onStartVoiceCall = { p -> navController.navigate(NexaRoutes.call(p, false)) },
                            onStartVideoCall = { p -> navController.navigate(NexaRoutes.call(p, true)) },
                            onOpenUserProfile = { uid -> navController.navigate(NexaRoutes.userProfile(uid)) }
                        )
                    }
                    composable(
                        route = NexaRoutes.CALL,
                        arguments = listOf(
                            navArgument("peerId") { type = NavType.StringType },
                            navArgument("isVideo") { type = NavType.BoolType }
                        )
                    ) { entry ->
                        val peerId = entry.arguments?.getString("peerId") ?: return@composable
                        val isVideo = entry.arguments?.getBoolean("isVideo") ?: false
                        CallScreen(
                            viewModel = messagingViewModel,
                            peerId = peerId,
                            isVideoCall = isVideo,
                            onEndCall = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
