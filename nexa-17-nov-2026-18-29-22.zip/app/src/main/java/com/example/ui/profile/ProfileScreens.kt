package com.example.ui.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.core.i18n.LocalNexaStrings
import com.example.domain.model.FriendshipState
import com.example.domain.model.PostItem
import com.example.domain.model.UserProfile
import com.example.ui.components.NexaAvatar
import com.example.ui.components.NexaIdBadge
import com.example.ui.components.ReportDialog
import com.example.ui.components.formatRelativeTime
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnProfileScreen(
    viewModel: ProfileViewModel,
    onOpenPrivacySettings: () -> Unit,
    onOpenNotifications: () -> Unit
) {
    val strings = LocalNexaStrings.current
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val ownPosts by viewModel.ownPosts.collectAsStateWithLifecycle()
    val friends by viewModel.friends.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showEditDialog by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.profileTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier.size(48.dp).testTag("profile_notifications_button")
                    ) {
                        Icon(Icons.Default.NotificationsNone, contentDescription = strings.notificationsTitle)
                    }
                    IconButton(
                        onClick = onOpenPrivacySettings,
                        modifier = Modifier.size(48.dp).testTag("profile_privacy_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = strings.privacySettings)
                    }
                    IconButton(
                        onClick = { viewModel.signOut() },
                        modifier = Modifier.size(48.dp).testTag("sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = strings.signOut)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().widthIn(max = 600.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                user?.let { profile ->
                    item {
                        ProfileHeaderCard(
                            profile = profile,
                            friendsCount = friends.size,
                            postsCount = ownPosts.size,
                            onIdCopied = { scope.launch { snackbarHostState.showSnackbar(strings.idCopied) } },
                            actions = {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { showEditDialog = true },
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("edit_profile_button"),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.editProfile)
                                    }
                                    OutlinedButton(
                                        onClick = onOpenPrivacySettings,
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("open_privacy_button"),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.privacySettings, maxLines = 1)
                                    }
                                }
                            }
                        )
                    }
                }

                items(ownPosts, key = { it.id }) { post ->
                    SimpleProfilePostCard(post)
                }
            }
        }
    }

    if (showEditDialog && user != null) {
        EditProfileDialog(
            user = user!!,
            onDismiss = { showEditDialog = false },
            onSave = { name, bio, avatarUri ->
                viewModel.updateProfile(name, bio, avatarUri)
                showEditDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    viewModel: ProfileViewModel,
    targetUserId: String,
    onBack: () -> Unit,
    onOpenChat: (String) -> Unit
) {
    val strings = LocalNexaStrings.current
    val targetUser by viewModel.observeTargetUser(targetUserId).collectAsStateWithLifecycle(initialValue = null)
    val posts by viewModel.observeTargetPosts(targetUserId).collectAsStateWithLifecycle(initialValue = emptyList())
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var friendshipState by remember { mutableStateOf(FriendshipState.NONE) }
    var showReportDialog by remember { mutableStateOf(false) }

    LaunchedEffect(targetUserId) {
        friendshipState = viewModel.getFriendshipState(targetUserId)
    }

    LaunchedEffect(Unit) {
        viewModel.feedback.collect {
            snackbarHostState.showSnackbar(it)
            friendshipState = viewModel.getFriendshipState(targetUserId)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                    }
                },
                title = { Text(targetUser?.username ?: targetUserId) },
                actions = {
                    targetUser?.let { user ->
                        IconButton(onClick = { showReportDialog = true }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Default.Flag, contentDescription = strings.reportUser)
                        }
                        IconButton(
                            onClick = {
                                viewModel.blockUser(user.id, strings.userBlockedMsg)
                                onBack()
                            },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.Block, contentDescription = strings.blockUser)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().widthIn(max = 600.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                targetUser?.let { profile ->
                    item {
                        ProfileHeaderCard(
                            profile = profile,
                            friendsCount = null,
                            postsCount = posts.size,
                            onIdCopied = { scope.launch { snackbarHostState.showSnackbar(strings.idCopied) } },
                            actions = {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    when (friendshipState) {
                                        FriendshipState.FRIENDS -> {
                                            OutlinedButton(
                                                onClick = {
                                                    viewModel.removeFriend(profile.id)
                                                    friendshipState = FriendshipState.NONE
                                                },
                                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                                shape = RoundedCornerShape(14.dp)
                                            ) {
                                                Text(strings.removeFriend)
                                            }
                                        }
                                        FriendshipState.REQUEST_SENT -> {
                                            OutlinedButton(
                                                onClick = {},
                                                enabled = false,
                                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                                shape = RoundedCornerShape(14.dp)
                                            ) {
                                                Text(strings.requestSent)
                                            }
                                        }
                                        else -> {
                                            Button(
                                                onClick = { viewModel.sendFriendRequest(profile.id, strings.requestSent) },
                                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                                shape = RoundedCornerShape(14.dp)
                                            ) {
                                                Text(strings.sendRequest)
                                            }
                                        }
                                    }
                                    Button(
                                        onClick = { onOpenChat(profile.id) },
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.messageAction)
                                    }
                                }
                            }
                        )
                    }
                }
                items(posts, key = { it.id }) { post ->
                    SimpleProfilePostCard(post)
                }
            }
        }
    }

    if (showReportDialog && targetUser != null) {
        ReportDialog(
            targetUser = targetUser!!,
            onDismiss = { showReportDialog = false },
            onSubmit = { reason, details ->
                viewModel.reportUser(targetUser!!.id, reason, details, strings.reportSubmitted)
                showReportDialog = false
            }
        )
    }
}

@Composable
private fun ProfileHeaderCard(
    profile: UserProfile,
    friendsCount: Int?,
    postsCount: Int,
    onIdCopied: () -> Unit,
    actions: @Composable () -> Unit
) {
    val strings = LocalNexaStrings.current
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NexaAvatar(
                avatarUri = profile.avatarUri,
                username = profile.username,
                size = 86.dp,
                hasRing = true
            )
            Text(
                text = profile.username,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            NexaIdBadge(userId = profile.id, onCopied = onIdCopied)
            if (profile.bio.isNotBlank()) {
                Text(
                    text = profile.bio,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                if (friendsCount != null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$friendsCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(strings.friendsCount, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$postsCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(strings.postsCount, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            actions()
        }
    }
}

@Composable
private fun SimpleProfilePostCard(post: PostItem) {
    val strings = LocalNexaStrings.current
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = formatRelativeTime(post.createdAt, strings.isArabic),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (post.content.isNotBlank()) {
                Text(post.content, style = MaterialTheme.typography.bodyMedium)
            }
            if (!post.imageUri.isNullOrBlank()) {
                AsyncImage(
                    model = post.imageUri,
                    contentDescription = post.content,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                    colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
                )
            }
        }
    }
}

@Composable
private fun EditProfileDialog(
    user: UserProfile,
    onDismiss: () -> Unit,
    onSave: (String, String, Uri?) -> Unit
) {
    val strings = LocalNexaStrings.current
    var username by remember { mutableStateOf(user.username) }
    var bio by remember { mutableStateOf(user.bio) }
    var pickedAvatar by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pickedAvatar = uri }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.editProfile) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("change_avatar_button")
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.changeAvatar)
                }
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text(strings.usernameLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_username_input")
                )
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text(strings.bioLabel) },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("edit_bio_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(username, bio, pickedAvatar) },
                enabled = username.trim().length >= 2,
                modifier = Modifier.testTag("save_profile_button")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}
