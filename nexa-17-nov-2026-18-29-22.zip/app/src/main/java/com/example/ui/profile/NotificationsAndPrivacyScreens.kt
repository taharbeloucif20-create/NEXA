package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalNexaStrings
import com.example.domain.model.PrivacyScope
import com.example.ui.components.NexaAvatar
import com.example.ui.components.formatRelativeTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    viewModel: ProfileViewModel,
    onBack: () -> Unit,
    onOpenUserProfile: (String) -> Unit
) {
    val strings = LocalNexaStrings.current
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                    }
                },
                title = { Text(strings.notificationsTitle, fontWeight = FontWeight.Bold) },
                actions = {
                    if (notifications.any { !it.read }) {
                        TextButton(
                            onClick = { viewModel.markAllNotificationsRead() },
                            modifier = Modifier.testTag("mark_all_read_button")
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.markAllRead)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (notifications.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.NotificationsNone, contentDescription = null, modifier = Modifier.size(48.dp))
                        Text(strings.noNotifications, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().widthIn(max = 600.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(notifications, key = { it.id }) { item ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (item.read) MaterialTheme.colorScheme.surface
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                .clickable {
                                    viewModel.markNotificationRead(item.id)
                                    onOpenUserProfile(item.actorId)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                if (!item.read) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = if (strings.isArabic) item.messageAr else item.messageEn,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (item.read) FontWeight.Normal else FontWeight.SemiBold
                                    )
                                    Text(
                                        text = formatRelativeTime(item.createdAt, strings.isArabic),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettingsScreen(
    viewModel: ProfileViewModel,
    onBack: () -> Unit
) {
    val strings = LocalNexaStrings.current
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val blockedUsers by viewModel.blockedUsers.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                    }
                },
                title = { Text(strings.privacySettings, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().widthIn(max = 600.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Appearance & Language
                item {
                    SettingsSectionCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.darkThemeLabel, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            Switch(
                                checked = isDarkTheme,
                                onCheckedChange = { viewModel.setDarkTheme(it) },
                                modifier = Modifier.testTag("settings_dark_theme_switch")
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(strings.languageLabel, style = MaterialTheme.typography.bodyLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = language == AppLanguage.ARABIC,
                                    onClick = { viewModel.setLanguage(AppLanguage.ARABIC) },
                                    label = { Text(strings.arabicOption) },
                                    modifier = Modifier.testTag("lang_arabic_chip")
                                )
                                FilterChip(
                                    selected = language == AppLanguage.ENGLISH,
                                    onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) },
                                    label = { Text(strings.englishOption) },
                                    modifier = Modifier.testTag("lang_english_chip")
                                )
                            }
                        }
                    }
                }

                // Privacy controls
                user?.let { profile ->
                    item {
                        SettingsSectionCard {
                            ScopeSelectorRow(
                                label = strings.profileVisibilityLabel,
                                selected = profile.profileVisibility,
                                options = listOf(
                                    PrivacyScope.EVERYONE to strings.everyone,
                                    PrivacyScope.FRIENDS_ONLY to strings.friendsOnly,
                                    PrivacyScope.PRIVATE to strings.privateOnly
                                ),
                                onSelect = { next ->
                                    viewModel.updatePrivacy(
                                        profileVisibility = next,
                                        allowFriendRequests = profile.allowFriendRequests,
                                        allowMessagesFrom = profile.allowMessagesFrom,
                                        showReadReceipts = profile.showReadReceipts,
                                        allowVideoDownloadsDefault = profile.allowVideoDownloadsDefault
                                    )
                                }
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            ScopeSelectorRow(
                                label = strings.whoCanMessageLabel,
                                selected = profile.allowMessagesFrom,
                                options = listOf(
                                    PrivacyScope.EVERYONE to strings.everyone,
                                    PrivacyScope.FRIENDS_ONLY to strings.friendsOnly,
                                    PrivacyScope.PRIVATE to strings.nobody
                                ),
                                onSelect = { next ->
                                    viewModel.updatePrivacy(
                                        profileVisibility = profile.profileVisibility,
                                        allowFriendRequests = profile.allowFriendRequests,
                                        allowMessagesFrom = next,
                                        showReadReceipts = profile.showReadReceipts,
                                        allowVideoDownloadsDefault = profile.allowVideoDownloadsDefault
                                    )
                                }
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(strings.whoCanRequestLabel, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                                Switch(
                                    checked = profile.allowFriendRequests,
                                    onCheckedChange = { next ->
                                        viewModel.updatePrivacy(
                                            profileVisibility = profile.profileVisibility,
                                            allowFriendRequests = next,
                                            allowMessagesFrom = profile.allowMessagesFrom,
                                            showReadReceipts = profile.showReadReceipts,
                                            allowVideoDownloadsDefault = profile.allowVideoDownloadsDefault
                                        )
                                    }
                                )
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(strings.readReceiptsLabel, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                                Switch(
                                    checked = profile.showReadReceipts,
                                    onCheckedChange = { next ->
                                        viewModel.updatePrivacy(
                                            profileVisibility = profile.profileVisibility,
                                            allowFriendRequests = profile.allowFriendRequests,
                                            allowMessagesFrom = profile.allowMessagesFrom,
                                            showReadReceipts = next,
                                            allowVideoDownloadsDefault = profile.allowVideoDownloadsDefault
                                        )
                                    }
                                )
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(strings.defaultAllowDownloadLabel, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                                Switch(
                                    checked = profile.allowVideoDownloadsDefault,
                                    onCheckedChange = { next ->
                                        viewModel.updatePrivacy(
                                            profileVisibility = profile.profileVisibility,
                                            allowFriendRequests = profile.allowFriendRequests,
                                            allowMessagesFrom = profile.allowMessagesFrom,
                                            showReadReceipts = profile.showReadReceipts,
                                            allowVideoDownloadsDefault = next
                                        )
                                    }
                                )
                            }
                        }
                    }
                }

                // Blocked Users
                item {
                    Text(strings.blockedUsersTitle, style = MaterialTheme.typography.titleMedium)
                }
                if (blockedUsers.isEmpty()) {
                    item {
                        SettingsSectionCard {
                            Text(strings.noBlockedUsers, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    items(blockedUsers, key = { it.id }) { blocked ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                NexaAvatar(avatarUri = blocked.avatarUri, username = blocked.username, size = 40.dp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(blocked.username, style = MaterialTheme.typography.titleMedium)
                                    Text(blocked.id, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                OutlinedButton(onClick = { viewModel.unblockUser(blocked.id) }) {
                                    Text(strings.unblock)
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = strings.localStorageNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun ScopeSelectorRow(
    label: String,
    selected: PrivacyScope,
    options: List<Pair<PrivacyScope, String>>,
    onSelect: (PrivacyScope) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (scope, title) ->
                FilterChip(
                    selected = selected == scope,
                    onClick = { onSelect(scope) },
                    label = { Text(title) }
                )
            }
        }
    }
}
