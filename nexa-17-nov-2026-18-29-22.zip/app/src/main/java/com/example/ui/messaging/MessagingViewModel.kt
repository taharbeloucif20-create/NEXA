package com.example.ui.messaging

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.media.MediaHelper
import com.example.core.media.VoicePlayerManager
import com.example.core.media.VoiceRecorderManager
import com.example.domain.model.ChatMessage
import com.example.domain.model.ConversationSummary
import com.example.domain.model.UserProfile
import com.example.domain.repository.MessagingRepository
import com.example.domain.repository.SocialRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MessagingViewModel(
    private val currentUserId: String,
    private val messagingRepository: MessagingRepository,
    private val socialRepository: SocialRepository,
    private val mediaHelper: MediaHelper,
    val voiceRecorder: VoiceRecorderManager,
    val voicePlayer: VoicePlayerManager
) : ViewModel() {

    val conversations: StateFlow<List<ConversationSummary>> =
        messagingRepository.observeConversations(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val friends: StateFlow<List<UserProfile>> =
        socialRepository.observeFriends(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activePeerId = MutableStateFlow<String?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activePeer: StateFlow<UserProfile?> = _activePeerId
        .flatMapLatest { peerId ->
            if (peerId == null) flowOf(null)
            else socialRepository.observeUser(peerId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeMessages: StateFlow<List<ChatMessage>> = _activePeerId
        .flatMapLatest { peerId ->
            if (peerId == null) flowOf(emptyList())
            else messagingRepository.observeMessages(currentUserId, peerId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playingMessageId: StateFlow<String?> = voicePlayer.playingMessageId
    val isRecording: StateFlow<Boolean> = voiceRecorder.isRecording

    private val _feedback = MutableSharedFlow<String>()
    val feedback: SharedFlow<String> = _feedback.asSharedFlow()

    fun openConversation(peerId: String) {
        _activePeerId.value = peerId
        viewModelScope.launch {
            messagingRepository.markConversationRead(currentUserId, peerId)
        }
    }

    fun markThreadRead(peerId: String) {
        viewModelScope.launch {
            messagingRepository.markConversationRead(currentUserId, peerId)
        }
    }

    fun sendText(peerId: String, text: String) {
        viewModelScope.launch {
            messagingRepository.sendTextMessage(currentUserId, peerId, text)
                .onFailure { _feedback.emit(it.message ?: "Cannot send message") }
        }
    }

    fun sendImage(peerId: String, pickedUri: Uri) {
        viewModelScope.launch {
            mediaHelper.persistPickedImage(pickedUri).onSuccess { savedUri ->
                messagingRepository.sendImageMessage(currentUserId, peerId, savedUri)
                    .onFailure { _feedback.emit(it.message ?: "Cannot send image") }
            }
        }
    }

    fun startVoiceRecording() {
        voiceRecorder.startRecording()
    }

    fun stopAndSendVoice(peerId: String) {
        val result = voiceRecorder.stopAndSave() ?: return
        viewModelScope.launch {
            messagingRepository.sendVoiceMessage(currentUserId, peerId, result.first, result.second)
                .onFailure { _feedback.emit(it.message ?: "Cannot send voice note") }
        }
    }

    fun cancelVoiceRecording() {
        voiceRecorder.cancelRecording()
    }

    fun toggleVoicePlayback(messageId: String, uri: String) {
        voicePlayer.togglePlay(messageId, uri)
    }

    fun logCall(peerId: String, isVideo: Boolean, durationSec: Long) {
        viewModelScope.launch {
            messagingRepository.logCallRecord(currentUserId, peerId, isVideo, durationSec)
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceRecorder.cancelRecording()
        voicePlayer.stop()
    }
}
