package com.example.ui.social

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.FriendRequestItem
import com.example.domain.model.SearchResults
import com.example.domain.model.UserProfile
import com.example.domain.repository.SocialRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SocialViewModel(
    private val currentUserId: String,
    private val socialRepository: SocialRepository
) : ViewModel() {

    val friends: StateFlow<List<UserProfile>> = socialRepository.observeFriends(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incomingRequests: StateFlow<List<FriendRequestItem>> = socialRepository.observeIncomingRequests(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow(SearchResults())
    val searchResults: StateFlow<SearchResults> = _searchResults.asStateFlow()

    private val _feedback = MutableSharedFlow<String>()
    val feedback: SharedFlow<String> = _feedback.asSharedFlow()

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            _searchResults.value = socialRepository.searchAll(currentUserId, query)
        }
    }

    fun sendFriendRequestById(
        targetId: String,
        sentMsg: String,
        notFoundMsg: String,
        selfMsg: String,
        alreadyFriendsMsg: String
    ) {
        viewModelScope.launch {
            val res = socialRepository.sendFriendRequest(currentUserId, targetId)
            res.onSuccess {
                _feedback.emit(sentMsg)
            }.onFailure { err ->
                val msg = when (err.message) {
                    "NOT_FOUND" -> notFoundMsg
                    "SELF" -> selfMsg
                    "ALREADY_FRIENDS" -> alreadyFriendsMsg
                    else -> err.message ?: notFoundMsg
                }
                _feedback.emit(msg)
            }
        }
    }

    fun acceptRequest(requestId: Long) {
        viewModelScope.launch {
            socialRepository.acceptFriendRequest(requestId)
        }
    }

    fun declineRequest(requestId: Long) {
        viewModelScope.launch {
            socialRepository.declineFriendRequest(requestId)
        }
    }

    fun removeFriend(friendId: String) {
        viewModelScope.launch {
            socialRepository.removeFriend(currentUserId, friendId)
        }
    }
}
