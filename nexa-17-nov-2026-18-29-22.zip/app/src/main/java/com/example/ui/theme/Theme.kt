package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val NexaDarkColorScheme = darkColorScheme(
    primary = PureWhite,
    onPrimary = ObsidianBlack,
    primaryContainer = GraphiteSurface,
    onPrimaryContainer = PureWhite,
    secondary = ZincMutedDark,
    onSecondary = ObsidianBlack,
    secondaryContainer = CharcoalElevated,
    onSecondaryContainer = AlabasterWhite,
    tertiary = AlabasterWhite,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = AlabasterWhite,
    surface = OnyxSurface,
    onSurface = AlabasterWhite,
    surfaceVariant = GraphiteSurface,
    onSurfaceVariant = ZincMutedDark,
    outline = HairlineDark,
    outlineVariant = CharcoalElevated,
    error = CrispDangerDark,
    onError = ObsidianBlack
)

private val NexaLightColorScheme = lightColorScheme(
    primary = ObsidianBlack,
    onPrimary = PureWhite,
    primaryContainer = MistSurface,
    onPrimaryContainer = ObsidianBlack,
    secondary = ZincMutedLight,
    onSecondary = PureWhite,
    secondaryContainer = SilverBorder,
    onSecondaryContainer = ObsidianBlack,
    tertiary = ObsidianBlack,
    onTertiary = PureWhite,
    background = AlabasterWhite,
    onBackground = ObsidianBlack,
    surface = PureWhite,
    onSurface = ObsidianBlack,
    surfaceVariant = MistSurface,
    onSurfaceVariant = ZincMutedLight,
    outline = HairlineLight,
    outlineVariant = SilverBorder,
    error = CrispDangerLight,
    onError = PureWhite
)

val NexaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun NexaTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NexaDarkColorScheme else NexaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NexaTypography,
        shapes = NexaShapes,
        content = content
    )
}
