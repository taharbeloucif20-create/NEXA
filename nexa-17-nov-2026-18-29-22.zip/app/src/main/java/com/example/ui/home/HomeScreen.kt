package com.example.ui.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.core.i18n.LocalNexaStrings
import com.example.domain.model.PostItem
import com.example.domain.model.StoryGroup
import com.example.domain.model.UserProfile
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    currentUserId: String,
    onOpenNotifications: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenUserProfile: (String) -> Unit
) {
    val strings = LocalNexaStrings.current
    val context = LocalContext.current
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val storyGroups by viewModel.storyGroups.collectAsStateWithLifecycle()
    val unreadNotifs by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val activeCommentPostId by viewModel.activeCommentPostId.collectAsStateWithLifecycle()
    val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showCreatePostDialog by remember { mutableStateOf(false) }
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var activeStoryGroup by remember { mutableStateOf<StoryGroup?>(null) }
    var reportTarget by remember { mutableStateOf<Pair<UserProfile, String?>?>(null) }

    LaunchedEffect(Unit) {
        viewModel.feedbackMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = strings.appName,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(
                        onClick = onOpenSearch,
                        modifier = Modifier.size(48.dp).testTag("home_search_button")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = strings.searchTab)
                    }
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier.size(48.dp).testTag("home_notifications_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifs > 0) {
                                    Badge { Text(unreadNotifs.toString()) }
                                }
                            }
                        ) {
                            Icon(Icons.Default.NotificationsNone, contentDescription = strings.notificationsTitle)
                        }
                    }
                    IconButton(
                        onClick = { showCreatePostDialog = true },
                        modifier = Modifier.size(48.dp).testTag("home_create_post_button")
                    ) {
                        Icon(Icons.Default.AddBox, contentDescription = strings.createPost)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 600.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 24h Stories Strip
                item {
                    StoriesStrip(
                        storyGroups = storyGroups,
                        onAddStory = { showCreateStoryDialog = true },
                        onOpenStoryGroup = { activeStoryGroup = it }
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                if (posts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DynamicFeed,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = strings.noPostsYet,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(posts, key = { it.id }) { post ->
                        PostCard(
                            post = post,
                            isOwnPost = post.author.id == currentUserId,
                            onAuthorClick = { onOpenUserProfile(post.author.id) },
                            onLikeClick = { viewModel.toggleLike(post.id) },
                            onCommentClick = { viewModel.openComments(post.id) },
                            onShareClick = {
                                viewModel.recordShare(post.id)
                                shareTextExternally(
                                    context,
                                    post.author.username,
                                    "${post.author.username} (${post.author.id}):\n${post.content}"
                                )
                            },
                            onDeleteClick = { viewModel.deletePost(post.id) },
                            onReportClick = { reportTarget = post.author to post.id },
                            onBlockClick = { viewModel.blockUser(post.author, strings.userBlockedMsg) }
                        )
                    }
                }
            }
        }
    }

    if (showCreatePostDialog) {
        CreateMediaDialog(
            title = strings.createPost,
            placeholder = strings.postPlaceholder,
            submitLabel = strings.publish,
            onDismiss = { showCreatePostDialog = false },
            onSubmit = { text, uri ->
                viewModel.createPost(text, uri)
                showCreatePostDialog = false
            }
        )
    }

    if (showCreateStoryDialog) {
        CreateMediaDialog(
            title = "${strings.addStory} • ${strings.expiresIn24h}",
            placeholder = strings.postPlaceholder,
            submitLabel = strings.publish,
            onDismiss = { showCreateStoryDialog = false },
            onSubmit = { text, uri ->
                viewModel.createStory(text, uri)
                showCreateStoryDialog = false
            }
        )
    }

    if (activeCommentPostId != null) {
        CommentsBottomSheet(
            comments = activeComments,
            onDismiss = { viewModel.closeComments() },
            onSubmitComment = { viewModel.addComment(it) }
        )
    }

    activeStoryGroup?.let { group ->
        StoryViewerDialog(
            group = group,
            onDismiss = { activeStoryGroup = null }
        )
    }

    reportTarget?.let { (user, contentId) ->
        ReportDialog(
            targetUser = user,
            onDismiss = { reportTarget = null },
            onSubmit = { reason, details ->
                viewModel.reportUser(user, contentId, reason, details, strings.reportSubmitted)
                reportTarget = null
            }
        )
    }
}

@Composable
private fun StoriesStrip(
    storyGroups: List<StoryGroup>,
    onAddStory: () -> Unit,
    onOpenStoryGroup: (StoryGroup) -> Unit
) {
    val strings = LocalNexaStrings.current
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = strings.storiesTitle,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .width(68.dp)
                        .clickable { onAddStory() }
                        .testTag("add_story_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = strings.addStory,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = strings.addStory,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            items(storyGroups, key = { it.author.id }) { group ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .width(68.dp)
                        .clickable { onOpenStoryGroup(group) }
                        .testTag("story_group_${group.author.id}")
                ) {
                    NexaAvatar(
                        avatarUri = group.author.avatarUri,
                        username = group.author.username,
                        size = 62.dp,
                        hasRing = true
                    )
                    Text(
                        text = group.author.username,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun PostCard(
    post: PostItem,
    isOwnPost: Boolean,
    onAuthorClick: () -> Unit,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onReportClick: () -> Unit,
    onBlockClick: () -> Unit
) {
    val strings = LocalNexaStrings.current
    var menuExpanded by remember { mutableStateOf(false) }
    val likeScale by animateFloatAsState(
        targetValue = if (post.likedByMe) 1.15f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "likeScale"
    )

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onAuthorClick() }
                ) {
                    NexaAvatar(
                        avatarUri = post.author.avatarUri,
                        username = post.author.username,
                        size = 42.dp
                    )
                    Column {
                        Text(
                            text = post.author.username,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = post.author.id,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = formatRelativeTime(post.createdAt, strings.isArabic),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.MoreHoriz, contentDescription = null)
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        if (isOwnPost) {
                            DropdownMenuItem(
                                text = { Text(strings.deletePost) },
                                onClick = {
                                    menuExpanded = false
                                    onDeleteClick()
                                },
                                leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null) }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text(strings.reportUser) },
                                onClick = {
                                    menuExpanded = false
                                    onReportClick()
                                },
                                leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text(strings.blockUser) },
                                onClick = {
                                    menuExpanded = false
                                    onBlockClick()
                                },
                                leadingIcon = { Icon(Icons.Default.Block, contentDescription = null) }
                            )
                        }
                    }
                }
            }

            if (post.content.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = post.content,
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            if (!post.imageUri.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                AsyncImage(
                    model = post.imageUri,
                    contentDescription = post.content,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 320.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop,
                    colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
                )
            }

            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(
                    onClick = onLikeClick,
                    modifier = Modifier.heightIn(min = 48.dp).testTag("like_post_${post.id}")
                ) {
                    Icon(
                        imageVector = if (post.likedByMe) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = strings.likes,
                        modifier = Modifier.size(20.dp).scale(likeScale),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("${post.likesCount}")
                }
                TextButton(
                    onClick = onCommentClick,
                    modifier = Modifier.heightIn(min = 48.dp).testTag("comment_post_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = strings.comments,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("${post.commentsCount}")
                }
                TextButton(
                    onClick = onShareClick,
                    modifier = Modifier.heightIn(min = 48.dp).testTag("share_post_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = strings.shares,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("${post.sharesCount}")
                }
            }
        }
    }
}

@Composable
private fun CreateMediaDialog(
    title: String,
    placeholder: String,
    submitLabel: String,
    onDismiss: () -> Unit,
    onSubmit: (String, Uri?) -> Unit
) {
    val strings = LocalNexaStrings.current
    var text by remember { mutableStateOf("") }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pickedUri = uri }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text(placeholder) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_media_text_input"),
                    minLines = 3,
                    maxLines = 5
                )
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("pick_media_image_button")
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(strings.addPhoto)
                }
                pickedUri?.let { uri ->
                    AsyncImage(
                        model = uri,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(text, pickedUri) },
                enabled = text.isNotBlank() || pickedUri != null,
                modifier = Modifier.testTag("submit_media_dialog_button")
            ) {
                Text(submitLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
private fun StoryViewerDialog(
    group: StoryGroup,
    onDismiss: () -> Unit
) {
    val strings = LocalNexaStrings.current
    var index by remember { mutableIntStateOf(0) }
    val currentStory = group.stories.getOrNull(index) ?: return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable {
                    if (index + 1 < group.stories.size) index++ else onDismiss()
                }
        ) {
            if (!currentStory.imageUri.isNullOrBlank()) {
                AsyncImage(
                    model = currentStory.imageUri,
                    contentDescription = currentStory.caption,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.65f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.8f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    group.stories.forEachIndexed { i, _ ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (i <= index) Color.White else Color.White.copy(alpha = 0.3f))
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NexaAvatar(
                            avatarUri = group.author.avatarUri,
                            username = group.author.username,
                            size = 38.dp
                        )
                        Column {
                            Text(group.author.username, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${formatRelativeTime(currentStory.createdAt, strings.isArabic)} • ${strings.expiresIn24h}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.75f)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = strings.close, tint = Color.White)
                    }
                }
            }

            if (currentStory.caption.isNotBlank()) {
                Text(
                    text = currentStory.caption,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(24.dp)
                )
            }
        }
    }
}
