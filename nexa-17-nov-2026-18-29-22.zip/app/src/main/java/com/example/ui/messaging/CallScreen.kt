package com.example.ui.messaging

import android.content.Context
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.LocalNexaStrings
import com.example.ui.components.NexaAvatar
import kotlinx.coroutines.delay

@Composable
fun CallScreen(
    viewModel: MessagingViewModel,
    peerId: String,
    isVideoCall: Boolean,
    onEndCall: () -> Unit
) {
    val strings = LocalNexaStrings.current
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(peerId) {
        viewModel.openConversation(peerId)
    }

    val peer by viewModel.activePeer.collectAsStateWithLifecycle()
    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    var isConnected by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(isVideoCall) }
    var isCameraEnabled by remember { mutableStateOf(isVideoCall) }
    var useFrontCamera by remember { mutableStateOf(true) }

    val audioManager = remember {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    LaunchedEffect(isSpeakerOn) {
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = isSpeakerOn
        audioManager.isMicrophoneMute = isMuted
    }

    LaunchedEffect(isMuted) {
        audioManager.isMicrophoneMute = isMuted
    }

    LaunchedEffect(Unit) {
        delay(1200)
        isConnected = true
        while (true) {
            delay(1000)
            elapsedSeconds++
        }
    }

    fun finishAndExit() {
        audioManager.isMicrophoneMute = false
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = false
        viewModel.logCall(peerId, isVideoCall, elapsedSeconds.coerceAtLeast(1L))
        onEndCall()
    }

    BackHandler {
        finishAndExit()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF09090B))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Live CameraX preview when Video Call & camera enabled
        if (isVideoCall && isCameraEnabled) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }
                },
                update = { previewView ->
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                    cameraProviderFuture.addListener({
                        try {
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }
                            val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA
                            else CameraSelector.DEFAULT_BACK_CAMERA
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
                        } catch (_: Exception) {
                        }
                    }, ContextCompat.getMainExecutor(context))
                },
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.35f))
            )
        }

        // Peer identity & timer
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 56.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NexaAvatar(
                avatarUri = peer?.avatarUri,
                username = peer?.username ?: peerId,
                size = 96.dp,
                hasRing = true
            )
            Text(
                text = peer?.username ?: peerId,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(999.dp))
            ) {
                val mins = elapsedSeconds / 60
                val secs = elapsedSeconds % 60
                val timerStr = "%02d:%02d".format(mins, secs)
                Text(
                    text = if (isConnected) "${strings.connected} • $timerStr" else strings.calling,
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }

        // Bottom monochrome call control bar
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF141417).copy(alpha = 0.92f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 28.dp)
                .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(28.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (isMuted) Color.White else Color(0xFF27272A))
                        .testTag("call_mute_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = if (isMuted) strings.unmute else strings.mute,
                        tint = if (isMuted) Color.Black else Color.White
                    )
                }

                IconButton(
                    onClick = { isSpeakerOn = !isSpeakerOn },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (isSpeakerOn) Color.White else Color(0xFF27272A))
                        .testTag("call_speaker_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = strings.speaker,
                        tint = if (isSpeakerOn) Color.Black else Color.White
                    )
                }

                if (isVideoCall) {
                    IconButton(
                        onClick = { isCameraEnabled = !isCameraEnabled },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (!isCameraEnabled) Color.White else Color(0xFF27272A))
                            .testTag("call_camera_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isCameraEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = strings.cameraOff,
                            tint = if (!isCameraEnabled) Color.Black else Color.White
                        )
                    }

                    IconButton(
                        onClick = { useFrontCamera = !useFrontCamera },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF27272A))
                            .testTag("call_switch_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cameraswitch,
                            contentDescription = strings.switchCamera,
                            tint = Color.White
                        )
                    }
                }

                IconButton(
                    onClick = { finishAndExit() },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .testTag("call_end_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = strings.endCall,
                        tint = Color.Black
                    )
                }
            }
        }
    }
}
