package com.example.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.i18n.AppLanguage
import com.example.domain.model.UserProfile
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val isRegisterMode: Boolean = false,
    val uniqueIdInput: String = "",
    val usernameInput: String = "",
    val passwordInput: String = "",
    val bioInput: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val newlyRegisteredUser: UserProfile? = null
)

class AuthViewModel(
    private val authRepository: AuthRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun setMode(register: Boolean) {
        _uiState.update { it.copy(isRegisterMode = register, errorMessage = null) }
    }

    fun onUniqueIdChanged(value: String) {
        _uiState.update { it.copy(uniqueIdInput = value, errorMessage = null) }
    }

    fun onUsernameChanged(value: String) {
        _uiState.update { it.copy(usernameInput = value, errorMessage = null) }
    }

    fun onPasswordChanged(value: String) {
        _uiState.update { it.copy(passwordInput = value, errorMessage = null) }
    }

    fun onBioChanged(value: String) {
        _uiState.update { it.copy(bioInput = value, errorMessage = null) }
    }

    fun login() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = authRepository.login(state.uniqueIdInput, state.passwordInput)
            result.fold(
                onSuccess = { _uiState.update { it.copy(isLoading = false) } },
                onFailure = { e -> _uiState.update { it.copy(isLoading = false, errorMessage = e.message ?: "Login failed") } }
            )
        }
    }

    fun register() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = authRepository.register(
                username = state.usernameInput,
                password = state.passwordInput,
                bio = state.bioInput,
                avatarUri = null
            )
            result.fold(
                onSuccess = { profile ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            newlyRegisteredUser = profile
                        )
                    }
                },
                onFailure = { e ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = e.message ?: "Registration failed"
                        )
                    }
                }
            )
        }
    }

    fun dismissRegisteredCard() {
        _uiState.update { it.copy(newlyRegisteredUser = null) }
    }

    fun toggleLanguage(current: AppLanguage) {
        viewModelScope.launch {
            val next = if (current == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
            settingsRepository.setLanguage(next)
        }
    }

    fun toggleDarkTheme(current: Boolean) {
        viewModelScope.launch {
            settingsRepository.setDarkTheme(!current)
        }
    }
}
