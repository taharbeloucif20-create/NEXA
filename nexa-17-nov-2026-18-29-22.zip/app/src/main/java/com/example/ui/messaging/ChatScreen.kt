package com.example.ui.messaging

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.core.i18n.LocalNexaStrings
import com.example.domain.model.ChatMessage
import com.example.domain.model.MessageStatus
import com.example.domain.model.MessageType
import com.example.ui.components.NexaAvatar
import com.example.ui.components.formatRelativeTime
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: MessagingViewModel,
    currentUserId: String,
    peerId: String,
    onBack: () -> Unit,
    onStartVoiceCall: (String) -> Unit,
    onStartVideoCall: (String) -> Unit,
    onOpenUserProfile: (String) -> Unit
) {
    val strings = LocalNexaStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(peerId) {
        viewModel.openConversation(peerId)
    }

    val peer by viewModel.activePeer.collectAsStateWithLifecycle()
    val messages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val playingMessageId by viewModel.playingMessageId.collectAsStateWithLifecycle()

    LaunchedEffect(messages.size) {
        viewModel.markThreadRead(peerId)
    }

    LaunchedEffect(Unit) {
        viewModel.feedback.collect { snackbarHostState.showSnackbar(it) }
    }

    var textDraft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.sendImage(peerId, uri)
    }

    var pendingAudioAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) pendingAudioAction?.invoke()
        else scope.launch { snackbarHostState.showSnackbar(strings.micPermissionRequired) }
        pendingAudioAction = null
    }

    val videoCallPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audioOk = results[Manifest.permission.RECORD_AUDIO] == true
        val cameraOk = results[Manifest.permission.CAMERA] == true
        if (audioOk && cameraOk) onStartVideoCall(peerId)
        else scope.launch { snackbarHostState.showSnackbar(strings.cameraPermissionRequired) }
    }

    fun runWithMicPermission(action: () -> Unit) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) action()
        else {
            pendingAudioAction = action
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp).testTag("chat_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.clickable { onOpenUserProfile(peerId) }
                    ) {
                        NexaAvatar(
                            avatarUri = peer?.avatarUri,
                            username = peer?.username ?: peerId,
                            size = 36.dp
                        )
                        Column {
                            Text(
                                text = peer?.username ?: peerId,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = peerId,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { runWithMicPermission { onStartVoiceCall(peerId) } },
                        modifier = Modifier.size(48.dp).testTag("start_voice_call_button")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = strings.voiceCall)
                    }
                    IconButton(
                        onClick = {
                            val micOk = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            val camOk = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            if (micOk && camOk) onStartVideoCall(peerId)
                            else videoCallPermissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA))
                        },
                        modifier = Modifier.size(48.dp).testTag("start_video_call_button")
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = strings.videoCall)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                Column {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    if (isRecording) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.GraphicEq, contentDescription = null)
                                Text(strings.recordingVoice, style = MaterialTheme.typography.titleMedium)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { viewModel.cancelVoiceRecording() }) {
                                    Text(strings.cancel)
                                }
                                Button(
                                    onClick = { viewModel.stopAndSendVoice(peerId) },
                                    modifier = Modifier.testTag("stop_send_voice_button")
                                ) {
                                    Text(strings.tapToStop)
                                }
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.size(48.dp).testTag("chat_pick_image_button")
                            ) {
                                Icon(Icons.Default.Image, contentDescription = strings.addPhoto)
                            }
                            IconButton(
                                onClick = { runWithMicPermission { viewModel.startVoiceRecording() } },
                                modifier = Modifier.size(48.dp).testTag("chat_record_voice_button")
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = strings.voiceNote)
                            }
                            OutlinedTextField(
                                value = textDraft,
                                onValueChange = { textDraft = it },
                                placeholder = { Text(strings.typeMessage) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("chat_message_input"),
                                shape = RoundedCornerShape(20.dp)
                            )
                            IconButton(
                                onClick = {
                                    if (textDraft.isNotBlank()) {
                                        viewModel.sendText(peerId, textDraft)
                                        textDraft = ""
                                    }
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .testTag("chat_send_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = strings.send,
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isMine = msg.senderId == currentUserId
                MessageBubble(
                    message = msg,
                    isMine = isMine,
                    isPlayingVoice = playingMessageId == msg.id,
                    onToggleVoice = {
                        msg.mediaUri?.let { uri -> viewModel.toggleVoicePlayback(msg.id, uri) }
                    }
                )
            }
        }
    }
}

@Composable
private fun MessageBubble(
    message: ChatMessage,
    isMine: Boolean,
    isPlayingVoice: Boolean,
    onToggleVoice: () -> Unit
) {
    val strings = LocalNexaStrings.current
    val bgColor = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val fgColor = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = bgColor,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .then(
                    if (!isMine) Modifier.border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                    else Modifier
                )
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                when (message.type) {
                    MessageType.TEXT -> {
                        Text(message.textContent, style = MaterialTheme.typography.bodyMedium, color = fgColor)
                    }
                    MessageType.IMAGE -> {
                        message.mediaUri?.let { uri ->
                            AsyncImage(
                                model = uri,
                                contentDescription = strings.addPhoto,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop,
                                colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
                            )
                        }
                    }
                    MessageType.VOICE -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clickable { onToggleVoice() }
                                .padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlayingVoice) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = strings.voiceNote,
                                tint = fgColor
                            )
                            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = fgColor)
                            Text(
                                text = "${strings.voiceNote} • ${message.durationSec}s",
                                style = MaterialTheme.typography.labelLarge,
                                color = fgColor
                            )
                        }
                    }
                    MessageType.CALL_VOICE, MessageType.CALL_VIDEO -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (message.type == MessageType.CALL_VIDEO) Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = null,
                                tint = fgColor
                            )
                            val label = if (message.type == MessageType.CALL_VIDEO) strings.videoCall else strings.voiceCall
                            Text(
                                text = "$label • ${message.durationSec}s",
                                style = MaterialTheme.typography.labelLarge,
                                color = fgColor
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = formatRelativeTime(message.createdAt, strings.isArabic),
                        style = MaterialTheme.typography.labelSmall,
                        color = fgColor.copy(alpha = 0.72f)
                    )
                    if (isMine) {
                        val statusText = when (message.status) {
                            MessageStatus.SENT -> strings.statusSent
                            MessageStatus.DELIVERED -> strings.statusDelivered
                            MessageStatus.READ -> strings.statusRead
                        }
                        Icon(
                            imageVector = if (message.status == MessageStatus.SENT) Icons.Default.Done else Icons.Default.DoneAll,
                            contentDescription = statusText,
                            modifier = Modifier.size(14.dp),
                            tint = fgColor.copy(alpha = if (message.status == MessageStatus.READ) 1f else 0.6f)
                        )
                    }
                }
            }
        }
    }
}
