package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.security.PasswordHasher
import com.example.data.local.NexaDatabase
import com.example.data.preferences.SessionPreferences
import com.example.data.repository.AuthRepositoryImpl
import com.example.data.repository.SocialRepositoryImpl
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class NexaCoreUnitTest {

    @Test
    fun passwordHasher_neverStoresPlaintextAndVerifiesSaltedHash() {
        val raw = "SuperSecret99!"
        val hash1 = PasswordHasher.hashPassword(raw)
        val hash2 = PasswordHasher.hashPassword(raw)

        assertFalse(hash1.contains(raw))
        assertNotEquals(hash1, hash2)
        assertTrue(PasswordHasher.verifyPassword(raw, hash1))
        assertTrue(PasswordHasher.verifyPassword(raw, hash2))
        assertFalse(PasswordHasher.verifyPassword("WrongPassword", hash1))
    }

    @Test
    fun authAndSocialFlow_registerLoginFriendAndBlock() = runTest {
        val context = ApplicationProvider.getApplicationContext<NexaApplication>()
        val db = Room.inMemoryDatabaseBuilder(context, NexaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.nexaDao()
        val prefs = SessionPreferences(context)
        val authRepo = AuthRepositoryImpl(dao, prefs)
        val socialRepo = SocialRepositoryImpl(dao)

        val userA = authRepo.register("أحمد", "pass1234", "مرحباً", null).getOrThrow()
        assertTrue(userA.id.startsWith("NX-"))
        val entityA = dao.getUserById(userA.id)!!
        assertNotEquals("pass1234", entityA.passwordHash)

        authRepo.signOut()
        assertNull(authRepo.currentUserId.first())

        val loggedIn = authRepo.login(userA.id, "pass1234").getOrThrow()
        assertEquals(userA.id, loggedIn.id)
        assertTrue(authRepo.login(userA.id, "wrongpass").isFailure)

        val userB = authRepo.register("سارة", "pass5678", "", null).getOrThrow()
        socialRepo.sendFriendRequest(userB.id, userA.id).getOrThrow()
        val reqs = socialRepo.observeIncomingRequests(userA.id).first()
        assertEquals(1, reqs.size)

        socialRepo.acceptFriendRequest(reqs.first().id).getOrThrow()
        val friendsOfA = socialRepo.observeFriends(userA.id).first()
        assertEquals(1, friendsOfA.size)
        assertEquals(userB.id, friendsOfA.first().id)

        socialRepo.blockUser(userA.id, userB.id).getOrThrow()
        assertTrue(socialRepo.observeFriends(userA.id).first().isEmpty())

        db.close()
    }
}
