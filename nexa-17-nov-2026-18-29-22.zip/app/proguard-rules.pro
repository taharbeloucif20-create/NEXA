# NEXA ProGuard / R8 Keep Rules
-keepclassmembers class * extends androidx.room.RoomDatabase {
    void <init>();
}
-keep class com.example.data.local.** { *; }
-keep class com.example.domain.model.** { *; }
-keepattributes Signature,InnerClasses,EnclosingMethod
